using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Outbox;
using Coelsa.Artifact.Kafka.Outbox.BackgroundServices;
using Coelsa.Artifact.Kafka.Support.Settings;
using Coelsa.Artifact.Kafka.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using System.Data.Common;

WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

string? environment = builder.Configuration.GetValue<string>("Environment");

#region Kafka Producer and Consumer

builder.Services.AddCoelsaOutboxProducer(builder.Configuration);

#endregion

#region Outbox

builder.Services.AddHostedService<OutboxProcessor>();

builder.Services.AddCoelsaOutboxService(builder.Configuration, environment ?? "dev");

#endregion

builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

WebApplication app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/kafka-producer/{amount}/{key}", async ([FromRoute] int amount, [FromRoute] int? key, [FromServices] IOutboxService outbox, IOptions<OutboxOptions> options, IConfiguration configuration) =>
{
    if (amount < 1)
        amount = 1;

    using SqlConnection connection = new(configuration[options.Value.SqlServer.ConnectionString]);

    await connection.OpenAsync();

    for (int i = 0; i < amount; i++)
    {
        Invoice data = new()
        {
            Id = Guid.NewGuid().ToString(),
            CustomerId = i + 1,
            TotalAmount = new Random().Next(100, 10000),
            Currency = i % 2 == 0 ? "USD" : "ARS"
        };

        CoelsaMessage<Invoice> evt = new(
            data, "invoice.created", "urn:coelsa.com.ar/billing/invoice")
        {
            Key = key == null ? Guid.NewGuid().ToString() : key.Value.ToString(),
        };

        using DbTransaction session = await connection.BeginTransactionAsync();

        try
        {

            //Aqu� se guarda la logica de negocio de la aplicaci�n.....
            ////...

            DateTimeOffset createdAt = new(DateTime.UtcNow.Date, TimeSpan.Zero);

            bool isSuccess = await outbox.SaveOutboxAsync(evt, "dev_arq_stream_updated", ProducerType.queue_producer, connection, session, createdAt);

            if (isSuccess)
            {
                await session.CommitAsync();

                Console.WriteLine($"Persisted delivered to {evt.Data.Id}");
            }
            else
            {
                await session.RollbackAsync();

                Console.WriteLine($"NotPersisted delivered to {evt.Data.Id}");
            }
        }
        catch (Exception)
        {
            await session.RollbackAsync();

            Console.WriteLine($"Debes manejar los errores en caso de excepci�n");
        }

    }

    return $"Se enviaron {amount} mensajes.";
});


app.Run();

