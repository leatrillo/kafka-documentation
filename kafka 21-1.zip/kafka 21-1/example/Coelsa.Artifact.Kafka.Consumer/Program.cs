﻿using Coelsa.Artifact.Kafka;
using Coelsa.Artifact.Kafka.Consumer.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);

builder.Configuration.AddUserSecrets<Program>();

string? environment = builder.Configuration.GetValue<string>("Environment");

builder.Services.AddLogging();

builder.Services.AddCoelsaKafkaQueueConsumer(builder.Configuration, environment ?? "dev");

// Background loop consumer
builder.Services.AddHostedService<ConsumerService>();

IHost host = builder.Build();
await host.RunAsync();
