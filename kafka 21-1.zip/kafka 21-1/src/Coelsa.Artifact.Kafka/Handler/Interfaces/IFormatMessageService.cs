﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IFormatMessageService
{
    string JsonSerialize<T>(T obj) where T : class;
    T? JsonDeserialize<T>(string message) where T : class;
}
