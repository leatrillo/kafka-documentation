﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

public interface IKafkaQueueProducer : IKafkaProducer { }
