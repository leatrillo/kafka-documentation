﻿using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using System.Data;

namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

public interface IOutboxService
{
    Task<bool> SaveOutboxAsync<T>(CoelsaMessage<T> message, string topic, ProducerType producerType, IDbConnection connection, IDbTransaction transaction, DateTimeOffset? createdAt = null, CancellationToken cancellationToken = default) where T : class;
}
