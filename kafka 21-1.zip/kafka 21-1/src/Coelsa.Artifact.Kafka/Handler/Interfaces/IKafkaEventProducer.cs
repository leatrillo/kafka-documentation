﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

public interface IKafkaEventProducer : IKafkaProducer { }
