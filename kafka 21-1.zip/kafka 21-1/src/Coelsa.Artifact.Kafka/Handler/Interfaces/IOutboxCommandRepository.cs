﻿using Coelsa.Artifact.Kafka.Model.SqlServer;
using System.Data;

namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IOutboxCommandRepository
{
    Task<bool> SaveMessageAsync(OutboxMessages message, IDbConnection connection, IDbTransaction transaction, DateTimeOffset? createdAt = null, CancellationToken cancellationToken = default);
}
