﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Outbox.BackgroundServices;
using Coelsa.Artifact.Kafka.Outbox.BackgroundServices.Interfaces;
using Coelsa.Artifact.Kafka.Outbox.Repositories;
using Coelsa.Artifact.Kafka.Outbox.Services;
using Coelsa.Artifact.Kafka.Outbox.Services.Interfaces;
using Coelsa.Artifact.Kafka.Support;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Coelsa.Artifact.Kafka.Outbox;

public static class OutboxSqlServerExtensions
{
    public static IServiceCollection AddCoelsaOutboxService(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        services.AddCoelsaAllKafkaProducer(configuration, environment);

        _ = KafkaTools.AddOutboxSettings(services, configuration);

        services.AddSingleton<IInstanceService, InstanceService>();

        services.TryAddScoped<DbSession>();

        services.TryAddTransient<IMessageClaimRepository, MessageClaimRepository>();

        services.AddScoped<IDistributedLock, DistributedLockRepository>();

        services.AddScoped<IOutboxProcessorService, OutboxProcessorService>();

        return services;
    }

    public static IServiceCollection AddCoelsaOutboxProducer(this IServiceCollection services, IConfiguration configuration)
    {
        _ = KafkaTools.AddOutboxSettings(services, configuration);

        services.TryAddSingleton<IFormatMessageService, FormatMessageService>();

        services.AddTransient<IOutboxCommandRepository, OutboxCommandRepository>();

        services.TryAddScoped<IOutboxService, OutboxService>();

        return services;
    }
}
