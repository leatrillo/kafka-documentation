﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model.SqlServer;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using System.Data;

namespace Coelsa.Artifact.Kafka.Outbox.Repositories;

internal class OutboxCommandRepository(IOptions<OutboxOptions> options) : IOutboxCommandRepository
{
    private readonly SqlServerOptions sqlOptions = options.Value.SqlServer;

    public async Task<bool> SaveMessageAsync(OutboxMessages message, IDbConnection connection, IDbTransaction transaction, DateTimeOffset? createdAt = null, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(message);

        string sql = @"INSERT INTO [{0}_OUTBOX_MESSAGES] ([OMSG_KEY], [OMSG_PRODUCER_TYPE], [OMSG_TOPIC], [OMSG_PAYLOAD], [OMSG_SPEC_VERSION], [OMSG_SOURCE], [OMSG_TYPE], [OMSG_TIME], [OMSG_DATA_CONTENT_TYPE], [OMSG_TRACE_ID], [OMSG_PROCESSED_AT], [OMSG_RETRY_COUNT], [OMSG_STATUS], [OMSG_CREATED_AT]) VALUES (@key, @producerType, @Topic, @Payload, @SpecVersion, @Source, @Type, @Time, @DataContentType, @TraceId, @ProcessedAt, @RetryCount, @Status, ISNULL(@CreatedAt, SYSDATETIMEOFFSET()))";

        string query = string.Format(sql, sqlOptions.Initials);

        if (connection is not SqlConnection sqlConnection || transaction is not SqlTransaction sqlTransaction)
            throw new ArgumentException("La conexión debe ser de tipo SqlConnection.", nameof(connection));

        using SqlCommand command = new(query, sqlConnection, sqlTransaction)
        {
            CommandTimeout = sqlOptions.CommandTimeoutSeconds
        };

        command.Parameters.Add("@Key", SqlDbType.NVarChar).Value = message.Key;

        command.Parameters.Add("@producerType", SqlDbType.Int).Value = (int)message.ProducerType;

        command.Parameters.Add("@Topic", SqlDbType.NVarChar).Value = message.Topic;

        command.Parameters.Add("@Payload", SqlDbType.NVarChar).Value = message.Payload;

        command.Parameters.Add("@SpecVersion", SqlDbType.NVarChar).Value = message.SpecVersion;

        command.Parameters.Add("@Source", SqlDbType.NVarChar).Value = message.Source;

        command.Parameters.Add("@Type", SqlDbType.NVarChar).Value = message.Type;

        command.Parameters.Add("@Time", SqlDbType.DateTimeOffset).Value = message.Time;

        command.Parameters.Add("@DataContentType", SqlDbType.NVarChar).Value = message.DataContentType;

        command.Parameters.Add("@TraceId", SqlDbType.NVarChar).Value = message.TraceId;

        command.Parameters.Add("@ProcessedAt", SqlDbType.DateTimeOffset).Value = message.ProcessedAt ?? (object)DBNull.Value;

        command.Parameters.Add("@RetryCount", SqlDbType.Int).Value = message.RetryCount;

        command.Parameters.Add("@Status", SqlDbType.Int).Value = (int)message.Status;

        command.Parameters.Add("@CreatedAt", SqlDbType.DateTimeOffset).Value = createdAt ?? (object)DBNull.Value;

        int rowsAffected = await command.ExecuteNonQueryAsync(cancellationToken);

        return rowsAffected != 1
        ? throw new InvalidOperationException($"Expected to insert 1 row, but {rowsAffected} rows were affected.")
        : true;
    }
}
