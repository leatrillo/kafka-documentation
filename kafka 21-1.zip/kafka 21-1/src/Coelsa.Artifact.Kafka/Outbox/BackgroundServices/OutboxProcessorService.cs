﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Model.SqlServer;
using Coelsa.Artifact.Kafka.Outbox.BackgroundServices.Interfaces;
using Coelsa.Artifact.Kafka.Outbox.Services.Interfaces;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.Options;
using System.Text.Json;

namespace Coelsa.Artifact.Kafka.Outbox.BackgroundServices;

internal class OutboxProcessorService(IDistributedLock distributedLock, IMessageClaimRepository claimService, IOptions<OutboxOptions> configuration, IOptions<QueueProducerOptions> queueOptions, IOptions<EventProducerOptions> eventOptions, IKafkaQueueProducer queueProducer, IKafkaEventProducer eventProducer, IInstanceService instance) : IOutboxProcessorService
{
    private readonly OutboxOptions outboxOptions = configuration.Value;

    private readonly QueueProducerOptions queueProducerOptions = queueOptions.Value;

    private readonly EventProducerOptions eventProducerOptions = eventOptions.Value;
    public async Task<int> ClaimMessagesPhaseAsync(CancellationToken cancellationToken)
    {
        const string lockKey = "outbox-claim-optimized";

        // Tiempo de espera corto para la operación
        TimeSpan lockTimeout = TimeSpan.FromSeconds(10);

        bool lockAcquired = await distributedLock.TryAcquireAsync(lockKey, lockTimeout, cancellationToken);

        if (!lockAcquired)
            return 0;

        try
        {
            // Esta es la operación RÁPIDA que debería completarse en ~10 ms
            int claimedCount = await claimService.ClaimMessagesAsync(outboxOptions.BatchSize, cancellationToken);

            return claimedCount;
        }
        finally
        {
            // Libere el bloqueo inmediatamente después de reclamarlo: ¡esta es la optimización clave!
            await distributedLock.ReleaseAsync(lockKey, CancellationToken.None);
        }
    }

    public async Task CleanupOrphanedMessagesAsync(CancellationToken cancellationToken)
    {
        if (!outboxOptions.OrphanCleanupEnabled)
            return;

        // Limpie solo ocasionalmente para evitar una carga innecesaria
        int cleanupThreshold = (int)(1.0 / outboxOptions.OrphanCleanupProbability);

        if (Random.Shared.Next(0, cleanupThreshold) == 0)
            await claimService.ReclaimOrphanedMessagesAsync(outboxOptions.OrphanageTimeout, cancellationToken);
    }

    public async Task ProcessClaimedMessagesPhaseAsync(CancellationToken cancellationToken)
    {
        // Obtener mensajes reclamados por esta instancia
        IEnumerable<OutboxMessages> claimedMessages = await claimService.GetClaimedMessagesAsync(cancellationToken);

        if (!claimedMessages.Any())
            return;

        // Procesar mensajes con concurrencia controlada
        SemaphoreSlim semaphore = new(outboxOptions.MaxConcurrency, outboxOptions.MaxConcurrency);

        int processedCount = 0;

        IEnumerable<Task> tasks = claimedMessages.Select(async message =>
        {
            try
            {
                await semaphore.WaitAsync(cancellationToken);
            }
            catch (OperationCanceledException)
            {
                return;
            }

            try
            {
                // Verificar que este mensaje todavía nos pertenece (verificación de seguridad)
                if (message.InstanceId != instance.GetInstanceId())
                    return;

                // Procesar el mensaje
                await ProcessSingleClaimedMessageAsync(message, cancellationToken);

                Interlocked.Increment(ref processedCount);
            }
            finally
            {
                try
                {
                    semaphore.Release();
                }
                catch (ObjectDisposedException)
                {
                    // Semaphore was disposed during shutdown, ignore
                }
            }
        });

        await Task.WhenAll(tasks);
    }

    private async Task ProcessSingleClaimedMessageAsync(OutboxMessages message, CancellationToken cancellationToken)
    {
        using JsonDocument doc = JsonDocument.Parse(message.Payload);

        CoelsaMessage<JsonDocument> evt = new(
        doc, message.Source, message.Type, message.SpecVersion, ToContentType(message.DataContentType))
        {
            Key = message.Key,
            Time = message.Time,
            TraceId = message.TraceId
        };

        if (message.ProducerType == ProducerType.queue_producer)
            await SendMessage(message, evt, queueProducer, queueProducerOptions, cancellationToken);
        else
            await SendMessage(message, evt, eventProducer, eventProducerOptions, cancellationToken);
    }

    private async Task SendMessage(OutboxMessages message, CoelsaMessage<JsonDocument> evt, IKafkaProducer producer, ProducerOptions options, CancellationToken cancellationToken)
    {
        try
        {
            if (options.EnableTransaction)
            {
                producer.BeginTransaction();

                PersistenceStatus status = await producer.PublishAsync(message.Topic, evt, cancellationToken);

                if (status != PersistenceStatus.NotPersisted)
                {
                    producer.CommitTransaction();

                    await claimService.ReleaseProcessedMessageAsync(message.Id, cancellationToken);
                }
                else
                {
                    producer.AbortTransaction();

                    await claimService.FailClaimedMessageAsync(message.Id, $"No se pudo persistir en kafka, status: {status}",
                        DateTime.UtcNow.AddMinutes(Math.Pow(2, message.RetryCount)), cancellationToken);
                }
            }
            else
            {
                PersistenceStatus status = await producer.PublishAsync(message.Topic, evt, cancellationToken);

                if (status != PersistenceStatus.NotPersisted)
                    await claimService.ReleaseProcessedMessageAsync(message.Id, cancellationToken);
                else
                    await claimService.FailClaimedMessageAsync(message.Id, $"No se pudo persistir en kafka, status: {status}",
                        DateTime.UtcNow.AddMinutes(Math.Pow(2, message.RetryCount)), cancellationToken);
            }
        }
        catch (Exception ex) when (ex.Message.Contains("PRIMARY KEY constraint"))
        {
            // Violación de restricción de clave principal: el mensaje ya existe, esto es lo esperado en escenarios de alta concurrencia
            // Marcar como procesado exitosamente ya que el mensaje ya está en el sistema
            if (options.EnableTransaction)
                producer.CommitTransaction();

            await claimService.ReleaseProcessedMessageAsync(message.Id, cancellationToken);
        }
        catch (Exception ex)
        {
            if (options.EnableTransaction)
                producer.AbortTransaction();

            // Intenta marcar el mensaje como fallido para volver a intentarlo
            await claimService.FailClaimedMessageAsync(message.Id, ex.Message,
                DateTime.UtcNow.AddMinutes(Math.Pow(2, message.RetryCount)), cancellationToken);

            throw;
        }
    }

    public Task<int> DeleteProcessedMessagesAsync(DateTime olderThan, CancellationToken cancellationToken = default) => outboxOptions.SqlServer.BatchSizeDeleteProcessed < 1 ? Task.FromResult(0) : claimService.DeleteProcessedMessagesAsync(olderThan, cancellationToken);

    private static DataContentType ToContentType(string type) => type switch
    {
        "application/json" => DataContentType.Json,
        _ => throw new ArgumentOutOfRangeException(nameof(type), $"Not expected direction value: {type}"),
    };
}
