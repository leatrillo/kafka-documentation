﻿namespace Coelsa.Artifact.Kafka.Support.Settings;

public sealed class RetryOptions
{
    /// <summary>
    /// Initializes a new instance of the <see cref="RetryOptions"/> class with default values.
    /// </summary>
    public RetryOptions()
    {
        MaxAttempts = 3;
        InitialDelay = TimeSpan.FromSeconds(1);
        MaxDelay = TimeSpan.FromMinutes(5);
        BackoffMultiplier = 2.0;
        UseJitter = true;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="RetryOptions"/> class with specified values.
    /// </summary>
    /// <param name="maxAttempts">The maximum number of retry attempts.</param>
    /// <param name="initialDelay">The initial retry delay.</param>
    /// <param name="maxDelay">The maximum retry delay.</param>
    /// <param name="backoffMultiplier">The backoff multiplier for exponential backoff.</param>
    /// <param name="useJitter">Whether to add jitter to retry delays.</param>
    public RetryOptions(int maxAttempts, TimeSpan initialDelay, TimeSpan maxDelay, double backoffMultiplier, bool useJitter)
    {
        if (maxAttempts < 0)
            throw new ArgumentException("Max attempts cannot be negative.", nameof(maxAttempts));
        if (initialDelay < TimeSpan.Zero)
            throw new ArgumentException("Initial delay cannot be negative.", nameof(initialDelay));
        if (maxDelay < TimeSpan.Zero)
            throw new ArgumentException("Max delay cannot be negative.", nameof(maxDelay));
        if (backoffMultiplier <= 0)
            throw new ArgumentException("Backoff multiplier must be positive.", nameof(backoffMultiplier));

        MaxAttempts = maxAttempts;
        InitialDelay = initialDelay;
        MaxDelay = maxDelay;
        BackoffMultiplier = backoffMultiplier;
        UseJitter = useJitter;
    }

    /// <summary>
    /// Gets the maximum number of retry attempts.
    /// Default is 3.
    /// </summary>
    public int MaxAttempts { get; init; } = 3;

    /// <summary>
    /// Gets the initial retry delay.
    /// Default is 1 second.
    /// </summary>
    public TimeSpan InitialDelay { get; init; } = TimeSpan.FromSeconds(1);

    /// <summary>
    /// Gets the maximum retry delay.
    /// Default is 5 minutes.
    /// </summary>
    public TimeSpan MaxDelay { get; init; } = TimeSpan.FromMinutes(5);

    /// <summary>
    /// Gets the backoff multiplier for exponential backoff.
    /// Default is 2.0.
    /// </summary>
    public double BackoffMultiplier { get; init; } = 2.0;

    /// <summary>
    /// Gets a value indicating whether jitter should be added to retry delays.
    /// Default is true.
    /// </summary>
    public bool UseJitter { get; init; } = true;

    /// <summary>
    /// Creates a new instance of <see cref="RetryOptions"/> with modified values.
    /// </summary>
    /// <param name="maxAttempts">The maximum number of retry attempts.</param>
    /// <param name="initialDelay">The initial retry delay.</param>
    /// <param name="maxDelay">The maximum retry delay.</param>
    /// <param name="backoffMultiplier">The backoff multiplier.</param>
    /// <param name="useJitter">Whether to use jitter.</param>
    /// <returns>A new instance with the specified values.</returns>
    public RetryOptions With(
        int? maxAttempts = null,
        TimeSpan? initialDelay = null,
        TimeSpan? maxDelay = null,
        double? backoffMultiplier = null,
        bool? useJitter = null)
    {
        return new RetryOptions(
            maxAttempts ?? MaxAttempts,
            initialDelay ?? InitialDelay,
            maxDelay ?? MaxDelay,
            backoffMultiplier ?? BackoffMultiplier,
            useJitter ?? UseJitter);
    }
}
