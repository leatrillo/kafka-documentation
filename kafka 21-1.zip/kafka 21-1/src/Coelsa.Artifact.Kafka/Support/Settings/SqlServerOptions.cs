﻿namespace Coelsa.Artifact.Kafka.Support.Settings;

public sealed class SqlServerOptions
{
    public string ConnectionString { get; set; } = string.Empty;
    public string Initials { get; init; } = "ARQ";
    public int CommandTimeoutSeconds { get; set; } = 30;
    public int BatchSizeDeleteProcessed { get; init; } = 1000;

    /// <summary>
    /// Obtiene o establece el tiempo de espera para detectar mensajes huérfanos.
    /// Los mensajes que hayan estado en estado de procesamiento durante más tiempo que este tiempo de espera se considerarán huérfanos y se liberarán para su reprocesamiento.
    /// El valor predeterminado es 5 minutos.
    /// </summary>
    public TimeSpan OrphanageTimeout { get; set; } = TimeSpan.FromMinutes(5);
    public ConnectionPoolingOptions Polling { get; init; } = new();
}
