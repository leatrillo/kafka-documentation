﻿namespace Coelsa.Artifact.Kafka.Support.Settings;

public class ConnectionPoolingOptions
{
    /// <summary>
    /// Gets or sets the minimum number of connections in the pool.
    /// Default is 5.
    /// </summary>
    public int MinPoolSize { get; init; } = 5;

    /// <summary>
    /// Gets or sets the maximum number of connections in the pool.
    /// Default is 100.
    /// </summary>
    public int MaxPoolSize { get; init; } = 100;

    /// <summary>
    /// Gets or sets the connection lifetime in seconds.
    /// Default is 300 seconds (5 minutes).
    /// </summary>
    public int ConnectionLifetimeSeconds { get; init; } = 300;

    /// <summary>
    /// Gets or sets whether connection pooling is enabled.
    /// Default is true.
    /// </summary>
    public bool Enabled { get; init; } = true;

    /// <summary>
    /// Gets or sets the connection idle timeout in seconds.
    /// Default is 180 seconds (3 minutes).
    /// </summary>
    public int IdleTimeoutSeconds { get; init; } = 180;

    /// <summary>
    /// Validates that all connection pooling options are within acceptable ranges.
    /// </summary>
    public void Validate()
    {
        if (MinPoolSize < 0)
            throw new ArgumentException("MinPoolSize cannot be negative.", nameof(MinPoolSize));

        if (MaxPoolSize <= 0)
            throw new ArgumentException("MaxPoolSize must be positive.", nameof(MaxPoolSize));

        if (MinPoolSize > MaxPoolSize)
            throw new ArgumentException("MinPoolSize cannot be greater than MaxPoolSize.", nameof(MinPoolSize));

        if (ConnectionLifetimeSeconds <= 0)
            throw new ArgumentException("ConnectionLifetimeSeconds must be positive.", nameof(ConnectionLifetimeSeconds));

        if (IdleTimeoutSeconds <= 0)
            throw new ArgumentException("IdleTimeoutSeconds must be positive.", nameof(IdleTimeoutSeconds));
    }
}
