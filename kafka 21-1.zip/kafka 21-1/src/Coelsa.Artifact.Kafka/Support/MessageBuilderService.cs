﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using System.Text;

namespace Coelsa.Artifact.Kafka.Support;

internal class MessageBuilderService(IFormatMessageService formatMessage) : IMessageBuilderService
{
    public Message<string, string> BuildMessage<T>(CoelsaMessage<T> message) where T : class
    {
        string contentType = "application/json";

        string serializedMessage = "";

        if (message.DataContentType == DataContentType.Json)
            serializedMessage = formatMessage.JsonSerialize(message.Data);

        return new()
        {
            Key = message.Key,
            Value = serializedMessage,
            Headers = [
                new("specVersion", Encoding.UTF8.GetBytes(message.SpecVersion)),
                new("id", Encoding.UTF8.GetBytes(message.Key)),
                new("source", Encoding.UTF8.GetBytes(message.Source)),
                new("type", Encoding.UTF8.GetBytes(message.Type)),
                new("time", Encoding.UTF8.GetBytes(message.Time.ToString())),
                new("dataContentType", Encoding.UTF8.GetBytes(contentType)),
                new("traceId", Encoding.UTF8.GetBytes(message.TraceId)),
            ]
        };
    }
}
