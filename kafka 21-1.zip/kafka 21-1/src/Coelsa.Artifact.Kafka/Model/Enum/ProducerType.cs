﻿namespace Coelsa.Artifact.Kafka.Model.Enum;

public enum ProducerType
{
    queue_producer,
    event_producer
}
