﻿using System.Reflection;

namespace Coelsa.Artifact.Kafka.Model.Enum;

public enum DataContentType
{
    [EnumStringValue("application/json")]
    Json
}

[AttributeUsage(AttributeTargets.Field)]
public class EnumStringValueAttribute(string value) : Attribute
{
    public string Value { get; } = value;
}

public static class EnumExtensions
{
    public static string GetStringValue(this System.Enum value)
    {
        FieldInfo? field = value.GetType().GetField(value.ToString());

        EnumStringValueAttribute? attr = field?.GetCustomAttribute<EnumStringValueAttribute>();

        return attr?.Value ?? value.ToString();
    }
}