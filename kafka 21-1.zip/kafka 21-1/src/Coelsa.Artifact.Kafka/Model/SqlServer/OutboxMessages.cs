﻿using Coelsa.Artifact.Kafka.Model.Enum;

namespace Coelsa.Artifact.Kafka.Model.SqlServer;

public sealed class OutboxMessages
{
    public string Id { get; init; } = string.Empty;
    public string Key { get; init; } = string.Empty;
    public ProducerType ProducerType { get; init; }
    public required string Topic { get; init; }
    public required string Payload { get; init; }
    public required string SpecVersion { get; init; }
    public required string Source { get; init; }
    public required string Type { get; init; }
    public required DateTimeOffset Time { get; init; }
    public required string DataContentType { get; init; }
    public required string TraceId { get; init; }
    public DateTimeOffset? CreatedAt { get; init; } = null;
    public DateTimeOffset? ProcessedAt { get; init; } = null;
    public int RetryCount { get; init; } = 0;
    public DateTime? NextRetryAt { get; init; }
    public MessageStatus Status { get; init; } = MessageStatus.Pending;
    public int Version { get; init; }
    public string? Error { get; init; }

    // Granular processing lock fields
    public string? ProcessingInstanceId { get; init; }
    public DateTime? ProcessingStartedAt { get; init; }
    public DateTime? ProcessingExpiresAt { get; init; }

    // Instance-based claim processing fields
    public Guid? InstanceId { get; init; }
    public DateTime? ClaimedAt { get; init; }
}

public enum MessageStatus
{
    Pending = 0,
    Processing = 1,
    Processed = 2,
    Failed = 3,
    Dead = 4
}
