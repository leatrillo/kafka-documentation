﻿namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class ConnectionPoolingOptionsTests
{
    [Fact]
    public void Validate_DefaultOptions_DoesNotThrow()
    {
        ConnectionPoolingOptions options = new();

        options.Validate();
    }

    [Fact]
    public void Validate_NegativeMinPoolSize_Throws()
    {
        ConnectionPoolingOptions options = new() { MinPoolSize = -1 };

        Assert.Throws<ArgumentException>(options.Validate);
    }

    [Fact]
    public void Validate_ZeroMaxPoolSize_Throws()
    {
        ConnectionPoolingOptions options = new() { MaxPoolSize = 0 };

        Assert.Throws<ArgumentException>(options.Validate);
    }

    [Fact]
    public void Validate_MinPoolSizeGreaterThanMaxPoolSize_Throws()
    {
        ConnectionPoolingOptions options = new() { MinPoolSize = 10, MaxPoolSize = 5 };

        Assert.Throws<ArgumentException>(options.Validate);
    }

    [Fact]
    public void Validate_NonPositiveConnectionLifetimeSeconds_Throws()
    {
        ConnectionPoolingOptions options = new() { ConnectionLifetimeSeconds = 0 };

        Assert.Throws<ArgumentException>(options.Validate);
    }

    [Fact]
    public void Validate_NonPositiveIdleTimeoutSeconds_Throws()
    {
        ConnectionPoolingOptions options = new() { IdleTimeoutSeconds = 0 };

        Assert.Throws<ArgumentException>(options.Validate);
    }
}
