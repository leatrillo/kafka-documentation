namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class SqlServerOptionsTests
{
    [Fact]
    public void DefaultValues_AreSetCorrectly()
    {
        SqlServerOptions options = new();
        Assert.Equal(string.Empty, options.ConnectionString);
        Assert.Equal("ARQ", options.Initials);
        Assert.Equal(30, options.CommandTimeoutSeconds);
        Assert.Equal(TimeSpan.FromMinutes(5), options.OrphanageTimeout);
        Assert.NotNull(options.Polling);
    }

    [Fact]
    public void CanSetProperties()
    {
        ConnectionPoolingOptions pooling = new() { MinPoolSize = 2 };

        SqlServerOptions options = new()
        {
            Initials = "ZZZ",
            Polling = pooling,
            ConnectionString = "Server=.;Database=Test;",
            CommandTimeoutSeconds = 60,
            OrphanageTimeout = TimeSpan.FromMinutes(10)
        };

        Assert.Equal("Server=.;Database=Test;", options.ConnectionString);
        Assert.Equal("ZZZ", options.Initials);
        Assert.Equal(60, options.CommandTimeoutSeconds);
        Assert.Equal(TimeSpan.FromMinutes(10), options.OrphanageTimeout);
        Assert.Same(pooling, options.Polling);
    }
}
