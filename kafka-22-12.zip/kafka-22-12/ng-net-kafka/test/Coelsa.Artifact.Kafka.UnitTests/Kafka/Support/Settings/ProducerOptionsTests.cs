namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class ProducerOptionsTests
{
    [Fact]
    public void DefaultValues_AreSetCorrectly()
    {
        QueueProducerOptions options = new();

        Assert.Equal(Acks.All, options.Acks);
        Assert.True(options.EnableIdempotence);
        Assert.True(options.EnableTransaction);
        Assert.Equal(TimeSpan.FromSeconds(30), options.RequestTimeout);
        Assert.Equal(TimeSpan.FromSeconds(60), options.MaxBlockMs);
        Assert.Equal(16384, options.BatchSize);
        Assert.Equal(TimeSpan.FromMilliseconds(5), options.LingerMs);
        Assert.Equal(CompressionType.None, options.CompressionType);
        Assert.Equal(5, options.MaxInFlight);
        Assert.Equal(5, options.Retries);
        Assert.Equal(TimeSpan.FromMilliseconds(100), options.RetryBackoffMs);
    }
}
