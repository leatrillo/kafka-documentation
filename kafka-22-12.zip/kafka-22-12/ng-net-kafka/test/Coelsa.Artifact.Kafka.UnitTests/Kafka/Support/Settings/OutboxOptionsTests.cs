namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class OutboxOptionsTests
{
    [Fact]
    public void DefaultValues_AreSetCorrectly()
    {
        OutboxOptions options = new();

        Assert.Equal(1, options.MaxConcurrency);
        Assert.Equal(TimeSpan.FromSeconds(10), options.ProcessingInterval);
        Assert.Equal(100, options.BatchSize);
        Assert.True(options.OrphanCleanupEnabled);
        Assert.Equal(0.1, options.OrphanCleanupProbability, 3);
        Assert.Equal(TimeSpan.FromMinutes(5), options.OrphanageTimeout);
        Assert.NotNull(options.Retries);
        Assert.NotNull(options.SqlServer);
    }

    [Fact]
    public void CanSetInitProperties()
    {
        RetryOptions retries = new();

        SqlServerOptions sqlServer = new();

        OutboxOptions options = new()
        {
            MaxConcurrency = 5,
            ProcessingInterval = TimeSpan.FromSeconds(20),
            BatchSize = 50,
            OrphanCleanupEnabled = false,
            OrphanCleanupProbability = 0.5,
            OrphanageTimeout = TimeSpan.FromMinutes(10),
            Retries = retries,
            SqlServer = sqlServer
        };

        Assert.Equal(5, options.MaxConcurrency);
        Assert.Equal(TimeSpan.FromSeconds(20), options.ProcessingInterval);
        Assert.Equal(50, options.BatchSize);
        Assert.False(options.OrphanCleanupEnabled);
        Assert.Equal(0.5, options.OrphanCleanupProbability, 3);
        Assert.Equal(TimeSpan.FromMinutes(10), options.OrphanageTimeout);
        Assert.Same(retries, options.Retries);
        Assert.Same(sqlServer, options.SqlServer);
    }
}
