namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class RetryOptionsTests
{
    [Fact]
    public void DefaultConstructor_SetsDefaultValues()
    {
        RetryOptions options = new();

        Assert.Equal(3, options.MaxAttempts);
        Assert.Equal(TimeSpan.FromSeconds(1), options.InitialDelay);
        Assert.Equal(TimeSpan.FromMinutes(5), options.MaxDelay);
        Assert.Equal(2.0, options.BackoffMultiplier);
        Assert.True(options.UseJitter);
    }

    [Fact]
    public void ParameterizedConstructor_SetsValues()
    {
        RetryOptions options = new(5, TimeSpan.FromSeconds(2), TimeSpan.FromSeconds(10), 1.5, false);

        Assert.Equal(5, options.MaxAttempts);
        Assert.Equal(TimeSpan.FromSeconds(2), options.InitialDelay);
        Assert.Equal(TimeSpan.FromSeconds(10), options.MaxDelay);
        Assert.Equal(1.5, options.BackoffMultiplier);
        Assert.False(options.UseJitter);
    }

    [Theory]
    [InlineData(-1, 1, 1, 1)]
    [InlineData(1, -1, 1, 1)]
    [InlineData(1, 1, -1, 1)]
    [InlineData(1, 1, 1, 0)]
    [InlineData(1, 1, 1, -1)]
    public void ParameterizedConstructor_InvalidValues_Throws(int maxAttempts, int initialDelaySec, int maxDelaySec, double backoffMultiplier)
    {
        Assert.Throws<ArgumentException>(() => new RetryOptions(
            maxAttempts,
            TimeSpan.FromSeconds(initialDelaySec),
            TimeSpan.FromSeconds(maxDelaySec),
            backoffMultiplier,
            true));
    }

    [Fact]
    public void With_ModifiesValuesCorrectly()
    {
        RetryOptions options = new();

        var modified = options.With(maxAttempts: 10, initialDelay: TimeSpan.FromSeconds(5), maxDelay: TimeSpan.FromSeconds(20), backoffMultiplier: 3.0, useJitter: false);

        Assert.Equal(10, modified.MaxAttempts);
        Assert.Equal(TimeSpan.FromSeconds(5), modified.InitialDelay);
        Assert.Equal(TimeSpan.FromSeconds(20), modified.MaxDelay);
        Assert.Equal(3.0, modified.BackoffMultiplier);
        Assert.False(modified.UseJitter);
    }
}
