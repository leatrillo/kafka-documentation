namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class SecurityOptionsTests
{
    [Fact]
    public void DefaultValues_AreSetCorrectly()
    {
        SecurityOptions options = new();
        Assert.Equal("kafkaPassword", options.Password);
        Assert.Equal("KafkaUsername", options.Username);
    }

    [Fact]
    public void CanSetInitProperties()
    {
        SecurityOptions options = new()
        {
            Username = "user1",
            Password = "pass1"
        };
        Assert.Equal("user1", options.Username);
        Assert.Equal("pass1", options.Password);
    }
}
