﻿namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support.Settings;

public class ConsumerOptionsTests
{
    [Fact]
    public void DefaultValues_AreSetCorrectly()
    {
        QueueConsumerOptions options = new();

        Assert.Equal(string.Empty, options.GroupId);
        Assert.Equal(AutoOffsetReset.Latest, options.AutoOffsetReset);
        Assert.False(options.EnableAutoCommit);
        Assert.Equal(TimeSpan.FromSeconds(30), options.SessionTimeout);
        Assert.Equal(TimeSpan.FromSeconds(3), options.HeartbeatInterval);
        Assert.Equal(TimeSpan.FromMilliseconds(100000), options.ConsumeTimeout);
        Assert.Equal(500, options.MaxPollRecords);
        Assert.Equal(1, options.FetchMinBytes);
        Assert.Equal(TimeSpan.FromMilliseconds(500), options.FetchMaxWait);
        Assert.False(options.EnablePartitionEof);
        Assert.Equal(1, options.MaxConcurrency);
    }

    [Fact]
    public void CanSetGroupId()
    {
        QueueConsumerOptions options = new() { GroupId = "grupo1" };

        Assert.Equal("grupo1", options.GroupId);
    }
}
