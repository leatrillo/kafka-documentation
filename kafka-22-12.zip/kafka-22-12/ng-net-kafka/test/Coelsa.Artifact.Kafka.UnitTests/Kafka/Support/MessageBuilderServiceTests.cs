using Coelsa.Artifact.Kafka.Model.Enum;
using System.Text;

namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support;

public class MessageBuilderServiceTests
{
    private readonly Mock<IFormatMessageService> formatMessageMock;
    public MessageBuilderServiceTests()
    {
        formatMessageMock = new Mock<IFormatMessageService>();
    }

    [Fact]
    public void BuildMessage_WithJsonContentType_SetsAllHeadersAndSerializesValue()
    {
        TestClass data = new() { Name = "abc", Value = 1 };

        CoelsaMessage<TestClass> coelsaMessage = new(data, "src", "type")
        {
            Key = "key1",
            DataContentType = DataContentType.Json,
            SpecVersion = "1.0",
            Time = DateTimeOffset.UtcNow,
            TraceId = "trace"
        };

        formatMessageMock.Setup(f => f.JsonSerialize(data)).Returns("serialized-json");

        MessageBuilderService builder = new(formatMessageMock.Object);

        Message<string, string> result = builder.BuildMessage(coelsaMessage);

        Assert.Equal("key1", result.Key);

        Assert.Equal("serialized-json", result.Value);

        Assert.Contains(result.Headers, h => h.Key == "specVersion" && Encoding.UTF8.GetString(h.GetValueBytes()) == "1.0");

        Assert.Contains(result.Headers, h => h.Key == "id" && Encoding.UTF8.GetString(h.GetValueBytes()) == "key1");

        Assert.Contains(result.Headers, h => h.Key == "source" && Encoding.UTF8.GetString(h.GetValueBytes()) == "src");

        Assert.Contains(result.Headers, h => h.Key == "type" && Encoding.UTF8.GetString(h.GetValueBytes()) == "type");

        Assert.Contains(result.Headers, h => h.Key == "dataContentType" && Encoding.UTF8.GetString(h.GetValueBytes()) == "application/json");

        Assert.Contains(result.Headers, h => h.Key == "traceId" && Encoding.UTF8.GetString(h.GetValueBytes()) == "trace");
    }

    [Fact]
    public void BuildMessage_WithNonJsonContentType_ValueIsEmpty()
    {
        TestClass data = new() { Name = "abc", Value = 1 };

        CoelsaMessage<TestClass> coelsaMessage = new(data, "src", "type")
        {
            Key = "key2",
            DataContentType = DataContentType.Json,
            SpecVersion = "1.0",
            Time = DateTimeOffset.UtcNow,
            TraceId = "trace"
        };
        MessageBuilderService builder = new(formatMessageMock.Object);

        Message<string, string> result = builder.BuildMessage(coelsaMessage);

        Assert.Equal("key2", result.Key);

        Assert.Null(result.Value);
    }

}
