namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support;

public class FormatMessageServiceTests
{
    private readonly FormatMessageService service = new();


    [Fact]
    public void JsonSerialize_ReturnsValidJson()
    {
        TestClass obj = new() { Name = "Sample", Value = 99 };

        string json = service.JsonSerialize(obj);

        Assert.Contains("Sample", json);

        Assert.Contains("99", json);
    }

    [Fact]
    public void JsonSerialize_ThrowsOnNull()
    {
        Assert.Throws<ArgumentNullException>(() => service.JsonSerialize<TestClass>(null));
    }

    [Fact]
    public void JsonSerialize_ThrowsOnSerializationException()
    {
        // Clase con referencia circular
        CircularReference a = new();

        a.Self = a;

        var ex = Assert.Throws<InvalidOperationException>(() => service.JsonSerialize(a));

        Assert.Contains("Failed to serialize", ex.Message);
    }

    [Fact]
    public void JsonDeserialize_ReturnsObject()
    {
        string json = "{\"name\":\"Sample\",\"value\":123}";

        TestClass? obj = service.JsonDeserialize<TestClass>(json);

        Assert.NotNull(obj);

        Assert.Equal("Sample", obj.Name);

        Assert.Equal(123, obj.Value);
    }

    [Fact]
    public void JsonDeserialize_ThrowsOnNullOrWhiteSpace()
    {
        Assert.Throws<ArgumentNullException>(() => service.JsonDeserialize<TestClass>(null));

        Assert.Throws<ArgumentException>(() => service.JsonDeserialize<TestClass>("   "));
    }

    [Fact]
    public void JsonDeserialize_ThrowsOnInvalidJson()
    {
        string invalidJson = "{name:Sample,value}";

        InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => service.JsonDeserialize<TestClass>(invalidJson));

        Assert.Contains("Failed to Deserialize", ex.Message);
    }

    private class CircularReference
    {
        public CircularReference? Self { get; set; }
    }
}
