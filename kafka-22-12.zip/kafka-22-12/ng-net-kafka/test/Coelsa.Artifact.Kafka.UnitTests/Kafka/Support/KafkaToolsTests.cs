using Microsoft.Extensions.Configuration;

namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Support;

public class KafkaToolsTests
{
    [Fact]
    public void AddOutboxSettings_ValidConfig_ReturnsOptions()
    {
        Dictionary<string, string> configDict = new()
        {
            {"OutboxOptions:SqlServer:Initials", "valid"},
            {"OutboxOptions:SqlServer:Polling:IntervalSeconds", "10"}
        };
        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();

        OutboxOptions options = KafkaTools.AddOutboxSettings(services, configuration);

        Assert.Equal("valid", options.SqlServer.Initials);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("SELECT")]
    [InlineData("DROP")]
    [InlineData("CREATE")]
    [InlineData("TRANSACTION")]
    [InlineData("Un comando cualquiera muy grande")]
    public void AddOutboxSettings_InvalidInitials_Throws(string initials)
    {
        Dictionary<string, string> configDict = new()
        {
            {"OutboxOptions:SqlServer:Initials", initials},
            {"OutboxOptions:SqlServer:Polling:IntervalSeconds", "10"}
        };
        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();

        Assert.Throws<ArgumentException>(() => KafkaTools.AddOutboxSettings(services, configuration));
    }

    [Fact]
    public void AddProducerQueueSettings_ValidConfig_ReturnsOptions()
    {
        Dictionary<string, string> configDict = new()
        {
            {"kafkaOptions:QueuesOptions:QueueName", "queue1"},
            {"kafkaOptions:QueuesProducer:ProducerName", "prod1"}
        };
        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();

        (QueueOptions, QueueProducerOptions) result = KafkaTools.AddProducerQueueSettings(services, configuration);

        Assert.NotNull(result.Item1);

        Assert.NotNull(result.Item2);
    }

    [Fact]
    public void AddConsumerQueueSettings_ValidConfig_ReturnsOptions()
    {
        Dictionary<string, string> configDict = new()
        {
            {"kafkaOptions:QueuesOptions:QueueName", "queue1"},
            {"kafkaOptions:QueuesConsumer:ConsumerName", "cons1"}
        };
        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();

        (QueueOptions, QueueConsumerOptions) result = KafkaTools.AddConsumerQueueSettings(services, configuration);

        Assert.NotNull(result.Item1);

        Assert.NotNull(result.Item2);
    }

    [Fact]
    public void AddProducerEventSettings_ValidConfig_ReturnsOptions()
    {
        Dictionary<string, string> configDict = new()
        {
            {"kafkaOptions:EventsOptions:EventName", "event1"},
            {"kafkaOptions:EventsProducer:ProducerName", "prod1"}
        };

        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();
        (EventOptions, EventProducerOptions) result = KafkaTools.AddProducerEventSettings(services, configuration);

        Assert.NotNull(result.Item1);

        Assert.NotNull(result.Item2);
    }

    [Fact]
    public void AddConsumerEventSettings_ValidConfig_ReturnsOptions()
    {
        Dictionary<string, string> configDict = new()
        {
            {"kafkaOptions:EventsOptions:EventName", "event1"},
            {"kafkaOptions:EventsConsumer:ConsumerName", "cons1"}
        };

        IConfigurationRoot configuration = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

        ServiceCollection services = new();

        (EventOptions, EventConsumerOptions) result = KafkaTools.AddConsumerEventSettings(services, configuration);

        Assert.NotNull(result.Item1);

        Assert.NotNull(result.Item2);
    }


}
