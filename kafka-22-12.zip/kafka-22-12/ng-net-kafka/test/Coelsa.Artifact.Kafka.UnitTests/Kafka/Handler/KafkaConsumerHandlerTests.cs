﻿namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Handler;

public class KafkaConsumerHandlerTests
{
    private readonly Mock<IFormatMessageService> formatMessageMock;

    private readonly Mock<IConsumer<string, string>> consumerMock;

    private readonly IServiceProvider serviceProvider;

    private readonly KafkaConsumerHandler handler;

    public KafkaConsumerHandlerTests()
    {
        formatMessageMock = new Mock<IFormatMessageService>();

        consumerMock = new Mock<IConsumer<string, string>>();

        ServiceCollection services = new();

        services.AddKeyedSingleton<IConsumer<string, string>>("queue_consumer", consumerMock.Object);

        services.AddSingleton(formatMessageMock.Object);

        serviceProvider = services.BuildServiceProvider();

        handler = new KafkaConsumerHandler(serviceProvider, formatMessageMock.Object);
    }

    [Fact]
    public void Consume_Commits_WhenHandlerReturnsTrue()
    {
        ConsumeResult<string, string> consumeResult = new()
        {
            Message = new Message<string, string> { Value = "{\"prop\":\"value\"}" }
        };

        consumerMock.Setup(c => c.Consume(It.IsAny<CancellationToken>())).Returns(consumeResult);

        TestClass expectedObj = new();

        formatMessageMock.Setup(f => f.JsonDeserialize<TestClass>(consumeResult.Message.Value)).Returns(expectedObj);

        bool result = handler.Consume<TestClass>(consumerMock.Object, (msg, ct) => true);

        Assert.True(result);

        consumerMock.Verify(c => c.Commit(consumeResult), Times.Once);
    }

    [Fact]
    public void Consume_DoesNotCommit_WhenHandlerReturnsFalse()
    {
        ConsumeResult<string, string> consumeResult = new()
        {
            Message = new Message<string, string> { Value = "{\"prop\":\"value\"}" }
        };

        consumerMock.Setup(c => c.Consume(It.IsAny<CancellationToken>())).Returns(consumeResult);

        formatMessageMock.Setup(f => f.JsonDeserialize<TestClass>(consumeResult.Message.Value)).Returns(new TestClass());

        bool result = handler.Consume<TestClass>(consumerMock.Object, (msg, ct) => false);

        Assert.False(result);

        consumerMock.Verify(c => c.Commit(It.IsAny<ConsumeResult<string, string>>()), Times.Never);
    }

    [Fact]
    public async Task ConsumeAsync_Commits_WhenHandlerReturnsTrue()
    {
        ConsumeResult<string, string> consumeResult = new()
        {
            Message = new Message<string, string> { Value = "{\"prop\":\"value\"}" }
        };

        consumerMock.Setup(c => c.Consume(It.IsAny<CancellationToken>())).Returns(consumeResult);

        formatMessageMock.Setup(f => f.JsonDeserialize<TestClass>(consumeResult.Message.Value)).Returns(new TestClass());

        bool result = await handler.ConsumeAsync<TestClass>(consumerMock.Object, async (msg, ct) =>
        {
            await Task.Delay(1, ct);

            return true;
        });

        Assert.True(result);

        consumerMock.Verify(c => c.Commit(consumeResult), Times.Once);
    }

    [Fact]
    public void Subscribe_SingleTopic_ReturnsConsumer()
    {
        string topic = "test-topic";

        IConsumer<string, string> consumer = handler.Subscribe(topic);

        Assert.Equal(consumerMock.Object, consumer);

        consumerMock.Verify(c => c.Subscribe(topic), Times.Once);
    }

    [Fact]
    public void Subscribe_MultipleTopics_ReturnsConsumer()
    {
        List<string> topics = ["topic1", "topic2"];

        IConsumer<string, string> consumer = handler.Subscribe(topics);

        Assert.Equal(consumerMock.Object, consumer);

        consumerMock.Verify(c => c.Subscribe(topics), Times.Once);
    }

}
