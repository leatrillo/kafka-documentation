namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Handler;

public class KafkaQueueProducerHandlerTests
{
    private readonly Mock<IProducer<string, string>> producerMock = new();
    private readonly Mock<IMessageBuilderService> messageBuilderMock = new();
    private readonly Mock<ILogger<KafkaQueueProducerHandler>> loggerMock = new();
    private readonly Mock<IOptions<QueueProducerOptions>> optionsMock = new();
    private readonly IServiceProvider serviceProvider;
    private readonly KafkaQueueProducerHandler handler;

    public KafkaQueueProducerHandlerTests()
    {
        QueueProducerOptions options = new() { EnableTransaction = false };

        optionsMock.Setup(o => o.Value).Returns(options);

        ServiceCollection services = new();

        services.AddKeyedSingleton("queue_producer", producerMock.Object);

        serviceProvider = services.BuildServiceProvider();

        handler = new KafkaQueueProducerHandler(
            serviceProvider,
            messageBuilderMock.Object,
            loggerMock.Object,
            optionsMock.Object
        );
    }

    [Fact]
    public void AbortTransaction_CallsProducerAbortTransaction()
    {
        handler.AbortTransaction();

        producerMock.Verify(x => x.AbortTransaction(), Times.Once);
    }

    [Fact]
    public void BeginTransaction_CallsProducerBeginTransaction()
    {
        handler.BeginTransaction();

        producerMock.Verify(x => x.BeginTransaction(), Times.Once);
    }

    [Fact]
    public void CommitTransaction_CallsProducerCommitTransaction()
    {
        handler.CommitTransaction();

        producerMock.Verify(x => x.CommitTransaction(), Times.Once);
    }

    [Fact]
    public void InitTransactions_CallsProducerInitTransactions()
    {
        handler.InitTransactions();

        producerMock.Verify(x => x.InitTransactions(It.IsAny<TimeSpan>()), Times.Once);
    }

    [Fact]
    public async Task PublishAsync_ReturnsPersistedStatus_WhenProducerSucceeds()
    {
        string topic = "test-topic";

        CoelsaMessage<TestClass> message = new(new(), "prueba", "prueba");

        Message<string, string> kafkaMessage = new();

        DeliveryResult<string, string> deliveryResult = new() { Status = PersistenceStatus.Persisted };

        messageBuilderMock.Setup(m => m.BuildMessage(message)).Returns(kafkaMessage);

        producerMock.Setup(p => p.ProduceAsync(topic, kafkaMessage, It.IsAny<CancellationToken>())).ReturnsAsync(deliveryResult);

        PersistenceStatus result = await handler.PublishAsync(topic, message);

        Assert.Equal(PersistenceStatus.Persisted, result);
    }

    [Theory]
    [InlineData(PersistenceStatus.PossiblyPersisted)]
    [InlineData(PersistenceStatus.NotPersisted)]
    public async Task PublishAsync_ReturnsNotPersistedStatus_WhenProducerNotSucceeds(PersistenceStatus status)
    {
        string topic = "test-topic";

        CoelsaMessage<TestClass> message = new(new(), "prueba", "prueba");

        Message<string, string> kafkaMessage = new();

        DeliveryResult<string, string> deliveryResult = new() { Status = status };

        messageBuilderMock.Setup(m => m.BuildMessage(message)).Returns(kafkaMessage);

        producerMock.Setup(p => p.ProduceAsync(topic, kafkaMessage, It.IsAny<CancellationToken>())).ReturnsAsync(deliveryResult);

        PersistenceStatus result = await handler.PublishAsync(topic, message);

        Assert.Equal(status, result);
    }


    [Fact]
    public async Task PublishAsync_ReturnsNotPersistedStatus_WhenProducerThrowsException()
    {
        string topic = "test-topic";

        CoelsaMessage<TestClass> message = new(new(), "prueba", "prueba");

        Message<string, string> kafkaMessage = new();

        messageBuilderMock.Setup(m => m.BuildMessage(message)).Returns(kafkaMessage);

        producerMock.Setup(p => p.ProduceAsync(topic, kafkaMessage, It.IsAny<CancellationToken>())).ThrowsAsync(new Exception("Kafka error"));

        PersistenceStatus result = await handler.PublishAsync(topic, message);

        Assert.Equal(PersistenceStatus.NotPersisted, result);

        loggerMock.Verify(l => l.Log(LogLevel.Warning, It.IsAny<EventId>(), It.Is<It.IsAnyType>((v, t) => v.ToString().Contains(topic)), It.IsAny<Exception>(), It.IsAny<Func<It.IsAnyType, Exception, string>>()), Times.Once);
    }
}
