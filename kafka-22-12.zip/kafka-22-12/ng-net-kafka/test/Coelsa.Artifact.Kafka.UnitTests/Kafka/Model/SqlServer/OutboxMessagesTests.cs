using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Model.SqlServer;

namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Model.SqlServer;

public class OutboxMessagesTests
{
    [Fact]
    public void OutboxMessages_RequiredProperties_AreSetCorrectly()
    {
        DateTimeOffset now = DateTimeOffset.UtcNow;

        OutboxMessages msg = new()
        {
            Id = "id1",
            ProducerType = ProducerType.queue_producer,
            Topic = "topic1",
            Payload = "payload",
            SpecVersion = "1.0",
            Source = "source",
            Type = "type",
            Time = now,
            DataContentType = "application/json",
            TraceId = "trace-123",
            Version = 1
        };

        Assert.Equal("id1", msg.Id);
        Assert.Equal(ProducerType.queue_producer, msg.ProducerType);
        Assert.Equal("topic1", msg.Topic);
        Assert.Equal("payload", msg.Payload);
        Assert.Equal("1.0", msg.SpecVersion);
        Assert.Equal("source", msg.Source);
        Assert.Equal("type", msg.Type);
        Assert.Equal(now, msg.Time);
        Assert.Equal("application/json", msg.DataContentType);
        Assert.Equal("trace-123", msg.TraceId);
        Assert.Equal(1, msg.Version);
    }

    [Fact]
    public void OutboxMessages_DefaultValues_AreSetCorrectly()
    {
        OutboxMessages msg = new()
        {
            Id = "id2",
            ProducerType = ProducerType.event_producer,
            Topic = "topic2",
            Payload = "payload2",
            SpecVersion = "1.0",
            Source = "source2",
            Type = "type2",
            Time = DateTimeOffset.UtcNow,
            DataContentType = "application/json",
            TraceId = "trace-456",
            Version = 2
        };

        Assert.Equal(string.Empty, msg.Key);
        Assert.Null(msg.CreatedAt);
        Assert.Null(msg.ProcessedAt);
        Assert.Equal(0, msg.RetryCount);
        Assert.Null(msg.NextRetryAt);
        Assert.Equal(MessageStatus.Pending, msg.Status);
        Assert.Null(msg.Error);
        Assert.Null(msg.ProcessingInstanceId);
        Assert.Null(msg.ProcessingStartedAt);
        Assert.Null(msg.ProcessingExpiresAt);
        Assert.Null(msg.InstanceId);
        Assert.Null(msg.ClaimedAt);
    }

    [Fact]
    public void OutboxMessages_OptionalProperties_CanBeSet()
    {
        DateTimeOffset now = DateTimeOffset.UtcNow;

        Guid guid = Guid.NewGuid();

        OutboxMessages msg = new()
        {
            Id = "id3",
            ProducerType = ProducerType.queue_producer,
            Topic = "topic3",
            Payload = "payload3",
            SpecVersion = "1.0",
            Source = "source3",
            Type = "type3",
            Time = now,
            DataContentType = "application/json",
            TraceId = "trace-789",
            Version = 3,
            Key = "key3",
            CreatedAt = now,
            ProcessedAt = now,
            RetryCount = 2,
            NextRetryAt = now.DateTime,
            Status = MessageStatus.Failed,
            Error = "error",
            ProcessingInstanceId = "proc-1",
            ProcessingStartedAt = now.DateTime,
            ProcessingExpiresAt = now.DateTime.AddMinutes(5),
            InstanceId = guid,
            ClaimedAt = now.DateTime
        };

        Assert.Equal("key3", msg.Key);
        Assert.Equal(now, msg.CreatedAt);
        Assert.Equal(now, msg.ProcessedAt);
        Assert.Equal(2, msg.RetryCount);
        Assert.Equal(now.DateTime, msg.NextRetryAt);
        Assert.Equal(MessageStatus.Failed, msg.Status);
        Assert.Equal("error", msg.Error);
        Assert.Equal("proc-1", msg.ProcessingInstanceId);
        Assert.Equal(now.DateTime, msg.ProcessingStartedAt);
        Assert.Equal(now.DateTime.AddMinutes(5), msg.ProcessingExpiresAt);
        Assert.Equal(guid, msg.InstanceId);
        Assert.Equal(now.DateTime, msg.ClaimedAt);
    }

}
