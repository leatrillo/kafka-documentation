using Coelsa.Artifact.Kafka.Model.Enum;

namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Model;

public class CoelsaMessageTests
{
    [Fact]
    public void CoelsaMessage_InitializesRequiredProperties()
    {
        TestClass data = new() { Name = "Sample", Value = 99 };
        CoelsaMessage<TestClass> msg = new(data, "source", "type");

        Assert.Equal(data, msg.Data);
        Assert.Equal("source", msg.Source);
        Assert.Equal("type", msg.Type);
    }

    [Fact]
    public void CoelsaMessage_DefaultValues_AreSet()
    {
        TestClass data = new() { Name = "Sample", Value = 99 };
        CoelsaMessage<TestClass> msg = new(data, "src", "tp");

        Assert.Equal("1.0", msg.SpecVersion);
        Assert.Equal(DataContentType.Json, msg.DataContentType);
        Assert.False(string.IsNullOrWhiteSpace(msg.Key));
        Assert.NotEqual(default, msg.Time);
        Assert.NotNull(msg.TraceId);
    }

    [Fact]
    public void CoelsaMessage_OverrideOptionalValues()
    {
        TestClass data = new() { Name = "Sample", Value = 99 };
        CoelsaMessage<TestClass> msg = new(data, "src", "tp", "2.0", DataContentType.Json)
        {
            Key = "custom-key",
            Time = new DateTimeOffset(2020, 1, 1, 0, 0, 0, TimeSpan.Zero),
            TraceId = "trace-xyz"
        };

        Assert.Equal("2.0", msg.SpecVersion);
        Assert.Equal(DataContentType.Json, msg.DataContentType);
        Assert.Equal("custom-key", msg.Key);
        Assert.Equal(new DateTimeOffset(2020, 1, 1, 0, 0, 0, TimeSpan.Zero), msg.Time);
        Assert.Equal("trace-xyz", msg.TraceId);
    }
}
