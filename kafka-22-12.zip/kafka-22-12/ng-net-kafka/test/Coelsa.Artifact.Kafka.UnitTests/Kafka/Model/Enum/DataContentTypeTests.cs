using Coelsa.Artifact.Kafka.Model.Enum;

namespace Coelsa.Artifact.Kafka.UnitTests.Kafka.Model.Enum;

public class DataContentTypeTests
{
    [Fact]
    public void GetStringValue_ReturnsEnumStringValueAttribute()
    {
        DataContentType value = DataContentType.Json;

        string result = value.GetStringValue();

        Assert.Equal("application/json", result);
    }
}
