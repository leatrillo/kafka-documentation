﻿namespace Coelsa.Artifact.Kafka.UnitTests.Help;

internal class TestClass
{
    public string Prop { get; set; } = string.Empty;
    public string Name { get; set; } = "Test";
    public int Value { get; set; } = 42;
}
