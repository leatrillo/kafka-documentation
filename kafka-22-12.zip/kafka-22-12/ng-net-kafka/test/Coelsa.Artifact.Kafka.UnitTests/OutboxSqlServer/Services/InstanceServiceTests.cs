using Coelsa.Artifact.Kafka.Outbox.Services;

namespace Coelsa.Artifact.Kafka.UnitTests.OutboxSqlServer.Services;

public class InstanceServiceTests
{
    [Fact]
    public void GetInstanceId_ReturnsConsistentGuid_ForSameInstance()
    {
        InstanceService service = new();

        Guid id1 = service.GetInstanceId();

        Guid id2 = service.GetInstanceId();

        Assert.Equal(id1, id2);
    }

    [Fact]
    public void GetInstanceId_ReturnsNonDefaultGuid()
    {
        InstanceService service = new();

        Guid id = service.GetInstanceId();

        Assert.NotEqual(Guid.Empty, id);
    }

    [Fact]
    public void GetInstanceId_DifferentInstances_ReturnDifferentGuids()
    {
        InstanceService service1 = new();

        InstanceService service2 = new();

        Assert.NotEqual(service1.GetInstanceId(), service2.GetInstanceId());
    }
}
