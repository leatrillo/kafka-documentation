using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Model.SqlServer;
using Coelsa.Artifact.Kafka.Outbox.Services;
using System.Data;

namespace Coelsa.Artifact.Kafka.UnitTests.OutboxSqlServer.Services;

public class OutboxServiceTests
{
    private readonly Mock<IOutboxCommandRepository> repositoryMock;
    private readonly Mock<IFormatMessageService> formatMock;
    private readonly CoelsaMessage<string> message;

    public OutboxServiceTests()
    {
        repositoryMock = new Mock<IOutboxCommandRepository>();
        formatMock = new Mock<IFormatMessageService>();
        message = new("data", "source", "type")
        {
            Key = "key",
            SpecVersion = "1.0",
            Time = System.DateTime.UtcNow,
            DataContentType = DataContentType.Json
        };
    }

    [Fact]
    public async Task SaveOutboxAsync_ReturnsTrue_WhenRepositoryReturnsTrue()
    {
        formatMock.Setup(f => f.JsonSerialize(message.Data)).Returns("serialized");
        repositoryMock.Setup(r => r.SaveMessageAsync(It.IsAny<OutboxMessages>(), It.IsAny<IDbConnection>(), It.IsAny<IDbTransaction>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        OutboxService service = new(repositoryMock.Object, formatMock.Object);
        bool result = await service.SaveOutboxAsync(message, "topic", ProducerType.queue_producer, Mock.Of<IDbConnection>(), Mock.Of<IDbTransaction>());

        Assert.True(result);
        repositoryMock.Verify(r => r.SaveMessageAsync(It.Is<OutboxMessages>(m => m.Key == "key" && m.Payload == "serialized" && m.Topic == "topic"), It.IsAny<IDbConnection>(), It.IsAny<IDbTransaction>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task SaveOutboxAsync_ReturnsFalse_WhenRepositoryReturnsFalse()
    {

        formatMock.Setup(f => f.JsonSerialize(message.Data)).Returns("serialized");
        repositoryMock.Setup(r => r.SaveMessageAsync(It.IsAny<OutboxMessages>(), It.IsAny<IDbConnection>(), It.IsAny<IDbTransaction>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        OutboxService service = new(repositoryMock.Object, formatMock.Object);
        bool result = await service.SaveOutboxAsync(message, "topic", ProducerType.queue_producer, Mock.Of<IDbConnection>(), Mock.Of<IDbTransaction>());

        Assert.False(result);
    }

    [Fact]
    public async Task SaveOutboxAsync_UsesCorrectPayloadFromFormatMessageService()
    {
        formatMock.Setup(f => f.JsonSerialize(message.Data)).Returns("custom-payload");
        repositoryMock.Setup(r => r.SaveMessageAsync(It.IsAny<OutboxMessages>(), It.IsAny<IDbConnection>(), It.IsAny<IDbTransaction>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        OutboxService service = new(repositoryMock.Object, formatMock.Object);
        await service.SaveOutboxAsync(message, "topic", ProducerType.queue_producer, Mock.Of<IDbConnection>(), Mock.Of<IDbTransaction>());

        repositoryMock.Verify(r => r.SaveMessageAsync(It.Is<OutboxMessages>(m => m.Payload == "custom-payload"), It.IsAny<IDbConnection>(), It.IsAny<IDbTransaction>(), It.IsAny<CancellationToken>()), Times.Once);
    }
}
