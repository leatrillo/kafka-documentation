using Coelsa.Artifact.Kafka.Outbox.Services;
using Microsoft.Extensions.Configuration;
using System.Reflection;

namespace Coelsa.Artifact.Kafka.UnitTests.OutboxSqlServer.Services;

public class DbSessionTests
{
    private static OutboxOptions GetOutboxOptions(string connKey, bool poolingEnabled = true) => new()
    {
        SqlServer = new SqlServerOptions
        {
            ConnectionString = connKey,

            Polling = new ConnectionPoolingOptions
            {
                Enabled = poolingEnabled,
                MinPoolSize = 2,
                MaxPoolSize = 10,
                ConnectionLifetimeSeconds = 60
            }
        }
    };

    [Fact]
    public void Constructor_ThrowsIfConnectionStringIsNullOrEmpty()
    {
        Mock<IConfiguration> config = new();

        config.Setup(c => c["connKey"]).Returns<string>(null);

        IOptions<OutboxOptions> options = Options.Create(GetOutboxOptions("connKey"));

        Assert.Throws<ArgumentNullException>(() => new DbSession(config.Object, options));
    }

    [Fact]
    public void Constructor_SetsPropertiesCorrectly()
    {
        Mock<IConfiguration> config = new();

        config.Setup(c => c["connKey"]).Returns("Server=.;Database=db;User Id=sa;Password=123;");

        IOptions<OutboxOptions> options = Options.Create(GetOutboxOptions("connKey"));

        DbSession session = new(config.Object, options);

        Assert.NotNull(session);
    }

    [Fact]
    public void BuildPooledConnectionString_ReturnsExpectedPoolingValues()
    {
        Mock<IConfiguration> config = new();

        config.Setup(c => c["connKey"]).Returns("Server=.;Database=db;User Id=sa;Password=123;");

        IOptions<OutboxOptions> options = Options.Create(GetOutboxOptions("connKey", poolingEnabled: true));

        DbSession session = new(config.Object, options);

        MethodInfo? method = typeof(DbSession).GetMethod("BuildPooledConnectionString", BindingFlags.NonPublic | BindingFlags.Instance);

        string? result = method!.Invoke(session, null) as string;

        Assert.Contains("Pooling=True", result);
        Assert.Contains("Min Pool Size=2", result);
        Assert.Contains("Max Pool Size=10", result);
        Assert.Contains("Load Balance Timeout=60", result);
    }

    [Fact]
    public void BuildPooledConnectionString_DisablesPoolingIfOptionFalse()
    {
        Mock<IConfiguration> config = new();

        config.Setup(c => c["connKey"]).Returns("Server=.;Database=db;User Id=sa;Password=123;");

        IOptions<OutboxOptions> options = Options.Create(GetOutboxOptions("connKey", poolingEnabled: false));

        DbSession session = new(config.Object, options);

        MethodInfo? method = typeof(DbSession).GetMethod("BuildPooledConnectionString", BindingFlags.NonPublic | BindingFlags.Instance);

        string? result = method!.Invoke(session, null) as string;

        Assert.Contains("Pooling=False", result);
    }
}
