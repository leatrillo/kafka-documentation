﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Coelsa.Artifact.Kafka.Handler;

internal class KafkaEventProducerHandler : IKafkaEventProducer
{
    private readonly IProducer<string, string> eventProducer;
    private readonly IMessageBuilderService messageBuilder;
    private readonly ILogger<KafkaEventProducerHandler> logger;

    public KafkaEventProducerHandler(IServiceProvider serviceProvider, IMessageBuilderService messageBuilder, ILogger<KafkaEventProducerHandler> logger, IOptions<EventProducerOptions> options)
    {
        eventProducer = serviceProvider.GetRequiredKeyedService<IProducer<string, string>>(ProducerType.event_producer.ToString());

        this.messageBuilder = messageBuilder;

        this.logger = logger;

        if (options.Value.EnableTransaction)
            InitTransactions();
    }

    public void AbortTransaction()
    {
        eventProducer.AbortTransaction();
    }

    public void BeginTransaction()
    {
        eventProducer.BeginTransaction();
    }

    public void CommitTransaction()
    {
        eventProducer.CommitTransaction();
    }

    public void InitTransactions(TimeSpan? timeout = null)
    {
        eventProducer.InitTransactions(timeout ?? TimeSpan.FromSeconds(30));
    }

    public async Task<PersistenceStatus> PublishAsync<T>(string topic, CoelsaMessage<T> message, CancellationToken cancellationToken = default) where T : class
    {
        try
        {
            Message<string, string> kafkaMessage = messageBuilder.BuildMessage(message);

            DeliveryResult<string, string> response = await eventProducer.ProduceAsync(topic, kafkaMessage, cancellationToken);

            return response.Status;

        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to publish message to topic {Topic}", topic);

            return PersistenceStatus.NotPersisted;
        }
    }
}
