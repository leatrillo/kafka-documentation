﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IKafkaEventProducer : IKafkaProducer { }
