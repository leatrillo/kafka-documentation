﻿using Coelsa.Artifact.Kafka.Handler;
using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Support;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System.Reflection;

namespace Coelsa.Artifact.Kafka;

public static class KafkaProducerExtensions
{
    public static IServiceCollection AddCoelsaProducerKafka(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        AddProducerKafkaQueue(services, configuration, environment);

        AddProducerKafkaEvent(services, configuration, environment);

        services.TryAddSingleton<IFormatMessageService, FormatMessageService>();

        services.TryAddSingleton<IMessageBuilderService, MessageBuilderService>();

        return services;
    }

    private static void AddProducerKafkaQueue(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        (QueueOptions config, QueueProducerOptions queueOptions) = KafkaTools.AddProducerQueueSettings(services, configuration);

        AddProducer(services, configuration, config, queueOptions, environment, ProducerType.queue_producer);

        services.TryAddSingleton<IKafkaQueueProducer, KafkaQueueProducerHandler>();
    }

    private static void AddProducerKafkaEvent(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        (EventOptions config, EventProducerOptions enventOptions) = KafkaTools.AddProducerEventSettings(services, configuration);

        AddProducer(services, configuration, config, enventOptions, environment, ProducerType.event_producer);

        services.TryAddSingleton<IKafkaEventProducer, KafkaEventProducerHandler>();
    }

    private static void AddProducer(this IServiceCollection services, IConfiguration configuration, OptionsBase config, ProducerOptions options, string environment, ProducerType type)
    {
        string? assemblyName = Assembly.GetEntryAssembly()?.GetName().Name;

        string hostname = Environment.MachineName;

        ArgumentNullException.ThrowIfNull(assemblyName);

        ArgumentNullException.ThrowIfNull(environment);

        string producerType = "queue-producer";

        if (type == ProducerType.event_producer)
            producerType = "event-producer";

        string clientId = $"{assemblyName.ToLower()}.{producerType}.{environment}.{hostname}";

        ProducerConfig producerConfig = new()
        {
            BootstrapServers = configuration[config.BootstrapServers],
            ClientId = clientId.ToLower(),
            Acks = options.Acks,
            EnableIdempotence = options.EnableIdempotence,
            RequestTimeoutMs = (int)options.RequestTimeout.TotalMilliseconds,
            MessageTimeoutMs = (int)options.MaxBlockMs.TotalMilliseconds,
            BatchSize = options.BatchSize,
            LingerMs = options.LingerMs.TotalMilliseconds,
            CompressionType = options.CompressionType,
            MaxInFlight = options.MaxInFlight,
            MessageSendMaxRetries = options.Retries,
            RetryBackoffMs = (int)options.RetryBackoffMs.TotalMilliseconds,
            SecurityProtocol = SecurityProtocol.SaslSsl,
            SaslMechanism = SaslMechanism.Plain,
            SaslUsername = configuration[config.Security.Username],
            SaslPassword = configuration[config.Security.Password],
            EnableSslCertificateVerification = false,
            TransactionalId = options.EnableTransaction ? $"producer-{Environment.MachineName.ToLower()}-{Guid.NewGuid()}" : ""
        };

        services.TryAddKeyedSingleton(type.ToString(), (sp, key) => new ProducerBuilder<string, string>(producerConfig).Build()
        );
    }
}
