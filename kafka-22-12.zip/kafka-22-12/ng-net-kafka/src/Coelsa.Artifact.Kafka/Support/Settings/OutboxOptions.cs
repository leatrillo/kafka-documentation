﻿namespace Coelsa.Artifact.Kafka.Support.Settings;

public sealed class OutboxOptions
{
    /// <summary>
    /// Obtiene o establece el número máximo de procesadores concurrentes.
    /// El valor predeterminado es 1.
    /// </summary>
    public int MaxConcurrency { get; init; } = 1;

    /// <summary>
    /// Obtiene o establece el intervalo de procesamiento para los mensajes de outbox.
    /// El valor predeterminado es 10 segundos.
    /// </summary>
    public TimeSpan ProcessingInterval { get; init; } = TimeSpan.FromSeconds(10);

    /// <summary>
    /// Obtiene o establece el tamaño del lote para procesar mensajes de outbox.
    /// El valor predeterminado es 100.
    /// </summary>
    public int BatchSize { get; init; } = 100;

    /// <summary>
    /// Obtiene o establece si la limpieza de mensajes huérfanos está habilitada.
    /// Si está deshabilitada, los mensajes huérfanos no se recuperarán automáticamente.
    /// El valor predeterminado es true.
    /// </summary>
    public bool OrphanCleanupEnabled { get; init; } = true;

    /// <summary>
    /// Obtiene o establece la probabilidad (0.0 a 1.0) de que una instancia intente
    /// limpiar mensajes huérfanos en cada ciclo de procesamiento.
    /// Esto ayuda a distribuir la carga de limpieza entre varias instancias.
    /// El valor predeterminado es 0.1 (10%).
    /// </summary>
    public double OrphanCleanupProbability { get; init; } = 0.1;

    /// <summary>
    /// Obtiene o establece el tiempo de espera para detectar mensajes huérfanos.
    /// Los mensajes que han estado en estado Processing más tiempo que este timeout
    /// se considerarán huérfanos y se liberarán para reprocesamiento.
    /// El valor predeterminado es 5 minutos.
    /// </summary>
    public TimeSpan OrphanageTimeout { get; init; } = TimeSpan.FromMinutes(5);
    /// <summary>
    /// 
    /// </summary>
    public TimeSpan ProcessedMessageRetention { get; init; } = TimeSpan.FromSeconds(60);

    public RetryOptions Retries { get; init; } = new();

    public SqlServerOptions SqlServer { get; init; } = new();
}
