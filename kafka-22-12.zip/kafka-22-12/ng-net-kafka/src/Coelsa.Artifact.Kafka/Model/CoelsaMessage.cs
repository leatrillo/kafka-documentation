﻿using Coelsa.Artifact.Kafka.Model.Enum;
using System.Diagnostics;

namespace Coelsa.Artifact.Kafka.Model;

public sealed record CoelsaMessage<T>(T Data, string Source, string Type, string SpecVersion = "1.0", DataContentType DataContentType = DataContentType.Json) where T : class
{
    public string Key { get; init; } = Guid.NewGuid().ToString();
    public DateTimeOffset Time { get; init; } = DateTimeOffset.Now;
    public string TraceId { get; init; } = Activity.Current?.TraceId.ToString() ?? string.Empty;
}




