﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Model.SqlServer;
using Coelsa.Artifact.Kafka.Outbox.Services;
using Coelsa.Artifact.Kafka.Outbox.Services.Interfaces;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using System.Data;

namespace Coelsa.Artifact.Kafka.Outbox.Repositories;

internal class MessageClaimRepository(DbSession session, IOptions<OutboxOptions> options, IInstanceService instance) : IMessageClaimRepository
{
    private readonly SqlServerOptions sqlOptions = options.Value.SqlServer;

    public async Task<int> ClaimMessagesAsync(int batchSize, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            WITH ClaimableCTE AS (
                SELECT TOP (@batchSize) [OMSG_ID]
                FROM {0}_OUTBOX_MESSAGES
                WHERE (
                        ([OMSG_STATUS] = @pendingStatus) OR
                        ([OMSG_STATUS] = @failedStatus AND [OSMG_NEXT_RETRY_AT] IS NOT NULL AND [OSMG_NEXT_RETRY_AT] <= GETUTCDATE()) OR
                        ([OMSG_STATUS] = @processingStatus AND [OMSG_CLAIMED_AT] < DATEADD(MINUTE, -@orphanageTimeoutMinutes, GETUTCDATE())) OR
                        ([OMSG_STATUS] = @processingStatus AND [OMSG_INSTANCE_ID] IS NULL) 
                      )
                  AND ([OMSG_INSTANCE_ID] IS NULL OR
                       [OMSG_CLAIMED_AT] < DATEADD(MINUTE, -@orphanageTimeoutMinutes, GETUTCDATE()))
                ORDER BY
                    CASE
                        WHEN [OMSG_STATUS] = @processingStatus THEN 0  -- Orphaned Processing messages have highest priority
                        WHEN [OMSG_STATUS] = @failedStatus THEN 1      -- Failed messages ready for retry have second priority
                        ELSE 2                                     -- Pending messages have lowest priority
                    END,
                    [OSMG_NEXT_RETRY_AT] ASC,
                    [OMSG_CREATED_AT] ASC
            )
            UPDATE t
            SET [OMSG_INSTANCE_ID] = @instanceId,
                [OMSG_STATUS] = @processingStatus,
                [OMSG_CLAIMED_AT] = GETUTCDATE(),
                [OSMG_VERSION] = [OSMG_VERSION] + 1
            FROM {0}_OUTBOX_MESSAGES t
            INNER JOIN ClaimableCTE c ON t.[OMSG_ID] = c.[OMSG_ID]
        ";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

        using SqlCommand command = new(formattedSql, connection);

        command.Parameters.Add("@batchSize", SqlDbType.Int).Value = batchSize;

        command.Parameters.Add("@instanceId", SqlDbType.UniqueIdentifier).Value = instance.GetInstanceId();

        command.Parameters.Add("@processingStatus", SqlDbType.Int).Value = (int)MessageStatus.Processing;

        command.Parameters.Add("@pendingStatus", SqlDbType.Int).Value = (int)MessageStatus.Pending;

        command.Parameters.Add("@failedStatus", SqlDbType.Int).Value = (int)MessageStatus.Failed;

        command.Parameters.Add("@orphanageTimeoutMinutes", SqlDbType.Int).Value = (int)sqlOptions.OrphanageTimeout.TotalMinutes;

        int claimedCount = await command.ExecuteNonQueryAsync(cancellationToken);

        return claimedCount;
    }

    public async Task FailClaimedMessageAsync(string messageId, string error, DateTime nextRetryAt, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            UPDATE {0}_OUTBOX_MESSAGES
            SET [OMSG_STATUS] = @failedStatus,
                [OMSG_ERROR] = @error,
                [OMSG_RETRY_COUNT] = [RetryCount] + 1,
                [OSMG_NEXT_RETRY_AT] = @nextRetryAt,
                [OMSG_INSTANCE_ID] = NULL,
                [OMSG_CLAIMED_AT] = NULL,
                [OSMG_VERSION] = [OSMG_VERSION] + 1
            WHERE [OMSG_ID] = @messageId
              AND [OMSG_INSTANCE_ID] = @instanceId
              AND [OMSG_STATUS] = @processingStatus
        ";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

        using SqlCommand command = new(formattedSql, connection);

        command.Parameters.Add("@messageId", SqlDbType.NVarChar, 255).Value = messageId;

        command.Parameters.Add("@instanceId", SqlDbType.UniqueIdentifier).Value = instance.GetInstanceId();

        command.Parameters.Add("@failedStatus", SqlDbType.Int).Value = (int)MessageStatus.Failed;

        command.Parameters.Add("@processingStatus", SqlDbType.Int).Value = (int)MessageStatus.Processing;

        command.Parameters.Add("@error", SqlDbType.NVarChar, 4000).Value = error;

        command.Parameters.Add("@nextRetryAt", SqlDbType.DateTime2).Value = nextRetryAt;

        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IEnumerable<OutboxMessages>> GetClaimedMessagesAsync(CancellationToken cancellationToken = default)
    {
        const string sql = @"
            SELECT
                [OMSG_ID], [OMSG_KEY], [OMSG_PRODUCER_TYPE], [OMSG_TOPIC],[OMSG_PAYLOAD], [OMSG_SPEC_VERSION], [OMSG_SOURCE], [OMSG_TYPE], [OMSG_TIME], [OMSG_DATA_CONTENT_TYPE], [OMSG_TRACE_ID], [OMSG_STATUS], [OMSG_CREATED_AT], [OMSG_PROCESSED_AT], [OMSG_ERROR],[OMSG_RETRY_COUNT],[OSMG_NEXT_RETRY_AT], [OSMG_VERSION], [OMSG_PROCESSING_INSTANCE_ID], [OMSG_PROCESSING_STARTED_AT],[OMSG_PROCESSING_EXPIRES_AT], [OMSG_INSTANCE_ID], [OMSG_CLAIMED_AT]
            FROM {0}_OUTBOX_MESSAGES
            WHERE [OMSG_INSTANCE_ID] = @instanceId
              AND [OMSG_STATUS] = @processingStatus
            ORDER BY [OMSG_CLAIMED_AT] ASC
        ";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

        using SqlCommand command = new(formattedSql, connection);

        command.Parameters.Add("@instanceId", SqlDbType.UniqueIdentifier).Value = instance.GetInstanceId();

        command.Parameters.Add("@processingStatus", SqlDbType.Int).Value = (int)MessageStatus.Processing;

        return await ReadMessagesAsync(command, cancellationToken);

    }

    public async Task<int> ReclaimOrphanedMessagesAsync(TimeSpan orphanageTimeout, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            UPDATE {0}_OUTBOX_MESSAGES
            SET [OMSG_INSTANCE_ID] = NULL,
                [OMSG_CLAIMED_AT] = NULL,
                [OMSG_STATUS] = @pendingStatus,
                [OSMG_VERSION] = [OSMG_VERSION] + 1
            WHERE [OMSG_STATUS] = @processingStatus
              AND [OMSG_CLAIMED_AT] < DATEADD(MINUTE, -@orphanageTimeoutMinutes, GETUTCDATE())
              AND [OMSG_INSTANCE_ID] IS NOT NULL
        ";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

        using SqlCommand command = new(formattedSql, connection);

        command.Parameters.Add("@processingStatus", SqlDbType.Int).Value = (int)MessageStatus.Processing;

        command.Parameters.Add("@pendingStatus", SqlDbType.Int).Value = (int)MessageStatus.Pending;

        command.Parameters.Add("@orphanageTimeoutMinutes", SqlDbType.Int).Value = (int)orphanageTimeout.TotalMinutes;

        int reclaimedCount = await command.ExecuteNonQueryAsync(cancellationToken);

        return reclaimedCount;
    }

    public async Task ReleaseProcessedMessageAsync(string messageId, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            UPDATE {0}_OUTBOX_MESSAGES
            SET [OMSG_STATUS] = @processedStatus,
                [OMSG_PROCESSED_AT] = GETUTCDATE(),
                [OMSG_INSTANCE_ID] = NULL,
                [OMSG_CLAIMED_AT] = NULL,
                [OSMG_VERSION] = [OSMG_VERSION] + 1
            WHERE [OMSG_ID] = @messageId
              AND [OMSG_INSTANCE_ID] = @instanceId
              AND [OMSG_STATUS] = @processingStatus
        ";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

        using SqlCommand command = new(formattedSql, connection);

        command.Parameters.Add("@messageId", SqlDbType.NVarChar, 255).Value = messageId;

        command.Parameters.Add("@instanceId", SqlDbType.UniqueIdentifier).Value = instance.GetInstanceId();

        command.Parameters.Add("@processedStatus", SqlDbType.Int).Value = (int)MessageStatus.Processed;

        command.Parameters.Add("@processingStatus", SqlDbType.Int).Value = (int)MessageStatus.Processing;

        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<int> DeleteProcessedMessagesAsync(DateTime olderThan, CancellationToken cancellationToken = default)
    {
        const string sql = @"
            DECLARE @BatchSize INT = @BatchSizeParam;
            DECLARE @DeletedCount INT = 0;
            DECLARE @RowsDeleted INT;

            WHILE 1 = 1
            BEGIN
                DELETE TOP (@BatchSize)
                FROM {0}_OUTBOX_MESSAGES
                WHERE [OMSG_STATUS] = @Status
                  AND [OMSG_PROCESSED_AT] < @OlderThan;

                SET @RowsDeleted = @@ROWCOUNT;

                IF @RowsDeleted = 0
                    BREAK;

                SET @DeletedCount = @DeletedCount + @RowsDeleted;
            END

            SELECT @DeletedCount AS DeletedCount;";

        string formattedSql = string.Format(sql, sqlOptions.Initials);


        return await ExecuteWithRetryAsync(async () =>
        {
            using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

            using SqlCommand command = new(formattedSql, connection);

            command.Parameters.Add("@BatchSizeParam", SqlDbType.Int).Value = sqlOptions.BatchSize;

            command.Parameters.Add("@Status", SqlDbType.Int).Value = (int)MessageStatus.Processed;

            command.Parameters.Add("@OlderThan", SqlDbType.DateTime2).Value = olderThan;

            command.CommandTimeout = sqlOptions.CommandTimeoutSeconds;

            object result = await command.ExecuteScalarAsync(cancellationToken);

            int deletedCount = Convert.ToInt32(result);

            return deletedCount;

        }, cancellationToken);
    }

    private static async Task<List<OutboxMessages>> ReadMessagesAsync(SqlCommand command, CancellationToken cancellationToken)
    {
        List<OutboxMessages> messages = [];

        using SqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            OutboxMessages message = new()
            {
                Id = reader.GetString("OMSG_ID"),
                Key = reader.GetString("OMSG_KEY"),
                ProducerType = (ProducerType)reader.GetInt32("OMSG_PRODUCER_TYPE"),
                Topic = reader.GetString("OMSG_TOPIC"),
                Payload = reader.GetString("OMSG_PAYLOAD"),
                SpecVersion = reader.GetString("OMSG_SPEC_VERSION"),
                Source = reader.GetString("OMSG_SOURCE"),
                Type = reader.GetString("OMSG_TYPE"),
                Time = reader.GetDateTime("OMSG_TIME"),
                DataContentType = reader.GetString("OMSG_DATA_CONTENT_TYPE"),
                TraceId = reader.GetString("OMSG_TRACE_ID"),
                Status = (MessageStatus)reader.GetInt32("OMSG_STATUS"),
                CreatedAt = reader.GetDateTime("OMSG_CREATED_AT"),
                ProcessedAt = await reader.IsDBNullAsync("OMSG_PROCESSED_AT", cancellationToken) ? null : reader.GetDateTime("OMSG_PROCESSEC_AT"),
                Error = await reader.IsDBNullAsync("OMSG_ERROR", cancellationToken) ? null : reader.GetString("OMSG_ERROR"),
                RetryCount = reader.GetInt32("OMSG_RETRY_COUNT"),
                NextRetryAt = await reader.IsDBNullAsync("OSMG_NEXT_RETRY_AT", cancellationToken) ? null : reader.GetDateTime("OSMG_NEXT_RETRY_AT"),
                Version = reader.GetInt32("OSMG_VERSION"),
                ProcessingInstanceId = await reader.IsDBNullAsync("OMSG_PROCESSING_INSTANCE_ID", cancellationToken) ? null : reader.GetString("OMSG_PROCESSING_INSTANCE_ID"),
                ProcessingStartedAt = await reader.IsDBNullAsync("OMSG_PROCESSING_STARTED_AT", cancellationToken) ? null : reader.GetDateTime("OMSG_PROCESSING_STARTED_AT"),
                ProcessingExpiresAt = await reader.IsDBNullAsync("OMSG_PROCESSING_EXPIRES_AT", cancellationToken) ? null : reader.GetDateTime("OMSG_PROCESSING_EXPIRES_AT"),
                InstanceId = await reader.IsDBNullAsync("OMSG_INSTANCE_ID", cancellationToken) ? null : reader.GetGuid("OMSG_INSTANCE_ID"),
                ClaimedAt = await reader.IsDBNullAsync("OMSG_CLAIMED_AT", cancellationToken) ? null : reader.GetDateTime("OMSG_CLAIMED_AT")
            };

            messages.Add(message);
        }

        return messages;

    }
    private static async Task<T> ExecuteWithRetryAsync<T>(Func<Task<T>> operation, CancellationToken cancellationToken)
    {
        int maxRetries = 3;

        TimeSpan retryDelay = TimeSpan.FromMilliseconds(500);

        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                return await operation();
            }
            catch (SqlException ex) when (attempt < maxRetries && IsTransientError(ex))
            {
                await Task.Delay(retryDelay * attempt, cancellationToken);
            }
        }

        return await operation(); // Final attempt without catching exceptions
    }

    private static bool IsTransientError(SqlException ex) =>
        // Common transient error numbers in SQL Server
        // Added 2627 (PRIMARY KEY constraint violation) as we now handle it gracefully with MERGE
        ex.Number is 2 or 20 or 64 or 233 or 2627 or 10053 or 10054 or 10060 or 40197 or 40501 or 40613;
}
