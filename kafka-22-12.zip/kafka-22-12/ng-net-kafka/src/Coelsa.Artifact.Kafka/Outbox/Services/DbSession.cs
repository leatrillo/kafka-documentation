﻿using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Data;

namespace Coelsa.Artifact.Kafka.Outbox.Services;

public sealed class DbSession
{
    private readonly SqlServerOptions SqlOptions;

    private readonly string ConnectionString;

    public DbSession(IConfiguration configuration, IOptions<OutboxOptions> options)
    {
        SqlOptions = options.Value.SqlServer;

        string? connectionstring = configuration[SqlOptions.ConnectionString];

        ArgumentException.ThrowIfNullOrWhiteSpace(connectionstring);

        ConnectionString = connectionstring;

    }

    public async Task<SqlConnection> CreateConnectionAsync(CancellationToken cancellationToken)
    {
        SqlConnection? connection = null;

        try
        {
            connection = new SqlConnection(BuildPooledConnectionString());

            await connection.OpenAsync(cancellationToken);

            // Verify connection is actually open
            return connection.State != ConnectionState.Open
                ? throw new InvalidOperationException("Connection opened but state is not Open") : connection;
        }
        catch (OperationCanceledException)
        {
            if (connection is not null)
                await connection.DisposeAsync();
            throw;
        }
        catch (Exception)
        {
            if (connection is not null)
                await connection.DisposeAsync();
            throw;
        }
    }

    private string BuildPooledConnectionString()
    {
        SqlConnectionStringBuilder builder = new(ConnectionString);

        ConnectionPoolingOptions poolingOptions = SqlOptions.Polling;

        if (poolingOptions.Enabled)
        {
            builder.Pooling = true;
            builder.MinPoolSize = poolingOptions.MinPoolSize;
            builder.MaxPoolSize = poolingOptions.MaxPoolSize;
            builder.ConnectTimeout = 30;

            // Connection lifetime controls how long a connection can be reused
            // This helps with load balancing and prevents stale connections
            if (poolingOptions.ConnectionLifetimeSeconds > 0)
                builder.LoadBalanceTimeout = poolingOptions.ConnectionLifetimeSeconds;
        }
        else
            builder.Pooling = false;

        return builder.ConnectionString;
    }

}
