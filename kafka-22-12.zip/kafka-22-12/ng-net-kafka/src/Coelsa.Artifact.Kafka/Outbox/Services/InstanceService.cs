﻿using Coelsa.Artifact.Kafka.Outbox.Services.Interfaces;

namespace Coelsa.Artifact.Kafka.Outbox.Services;

internal sealed class InstanceService : IInstanceService
{
    /// <summary>
    /// Obtiene el identificador único de instancia para este servicio.
    /// </summary>
    private Guid InstanceId { get; } = Guid.NewGuid();

    public Guid GetInstanceId()
    {
        return InstanceId;
    }
}
