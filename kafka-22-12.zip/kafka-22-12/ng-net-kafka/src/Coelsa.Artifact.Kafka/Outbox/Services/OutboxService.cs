﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Model.SqlServer;
using System.Data;
using System.Diagnostics;

namespace Coelsa.Artifact.Kafka.Outbox.Services;

internal sealed class OutboxService(IOutboxCommandRepository repository, IFormatMessageService messageFormat) : IOutboxService
{

    public async Task<bool> SaveOutboxAsync<T>(CoelsaMessage<T> message, string topic, ProducerType producerType, IDbConnection connection, IDbTransaction transaction, CancellationToken cancellationToken = default) where T : class
    {
        return await repository.SaveMessageAsync(new OutboxMessages
        {
            Id = Guid.NewGuid().ToString("N"),
            Key = message.Key,
            ProducerType = producerType,
            Topic = topic,
            Payload = messageFormat.JsonSerialize(message.Data),
            SpecVersion = message.SpecVersion,
            Source = message.Source,
            Type = message.Type,
            Time = message.Time,
            DataContentType = message.DataContentType.GetStringValue(),
            TraceId = Activity.Current?.TraceId.ToString() ?? string.Empty,
        }, connection, transaction, cancellationToken);

    }
}
