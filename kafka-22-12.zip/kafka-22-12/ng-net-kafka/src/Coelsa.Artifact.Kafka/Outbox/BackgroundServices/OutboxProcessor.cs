﻿using Coelsa.Artifact.Kafka.Outbox.BackgroundServices.Interfaces;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Coelsa.Artifact.Kafka.Outbox.BackgroundServices;

public sealed class OutboxProcessor(IServiceProvider serviceProvider, IOptions<OutboxOptions> configuration, ILogger<OutboxProcessor> logger) : BackgroundService
{
    private readonly OutboxOptions outboxOptions = configuration.Value;
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using IServiceScope scope = serviceProvider.CreateScope();

                IOutboxProcessorService outboxService = scope.ServiceProvider.GetRequiredService<IOutboxProcessorService>();

                // Operación de reclamación FAST bajo bloqueo distribuido (~10 ms)
                int claimedCount = await outboxService.ClaimMessagesPhaseAsync(stoppingToken);

                if (claimedCount == 0)
                {
                    // No hay mensajes para procesar, opcionalmente limpie los mensajes huérfanos
                    await outboxService.CleanupOrphanedMessagesAsync(stoppingToken);

                    // Eliminar mensajes procesados
                    await outboxService.DeleteProcessedMessagesAsync(DateTime.UtcNow.Add(-outboxOptions.ProcessedMessageRetention), stoppingToken);

                    try
                    {
                        await Task.Delay(outboxOptions.ProcessingInterval, stoppingToken);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }

                    continue;
                }

                // Fase de procesamiento LENTO SIN bloqueo distribuido (puede ejecutarse en paralelo con otras instancias)
                await outboxService.ProcessClaimedMessagesPhaseAsync(stoppingToken);

                // Eliminar mensajes procesados
                await outboxService.DeleteProcessedMessagesAsync(DateTime.UtcNow.Add(-outboxOptions.ProcessedMessageRetention), stoppingToken);

            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error occurred while processing outbox messages");
            }

            try
            {
                await Task.Delay(outboxOptions.ProcessingInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }
}
