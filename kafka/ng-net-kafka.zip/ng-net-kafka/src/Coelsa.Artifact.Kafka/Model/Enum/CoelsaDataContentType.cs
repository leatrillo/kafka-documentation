﻿namespace Coelsa.Artifact.Kafka.Model.Enum;
public enum CoelsaDataContentType
{
    Json
}
