﻿namespace Coelsa.Artifact.Outbox.SqlServer.Repositories;
internal class OutboxSqlServerQueryRepository
{
}
