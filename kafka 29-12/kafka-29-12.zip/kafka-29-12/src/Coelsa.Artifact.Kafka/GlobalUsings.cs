global using Confluent.Kafka;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
