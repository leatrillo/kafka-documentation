﻿namespace Coelsa.Artifact.Kafka.Support.Settings;

internal abstract class OptionsBase
{
    public string BootstrapServers { get; init; } = string.Empty;
    public SecurityOptions Security { get; init; } = new();
}

internal sealed class QueueOptions : OptionsBase
{
    public QueueOptions() => BootstrapServers = "SecretsSettings:KafkaQueuesBootstrapServers";
}
internal sealed class EventOptions : OptionsBase
{
    public EventOptions() => BootstrapServers = "SecretsSettings:KafkaEventsBootstrapServers";
}
internal sealed class QueueProducerOptions : ProducerOptions { }
internal sealed class EventProducerOptions : ProducerOptions { }
internal sealed class QueueConsumerOptions : ConsumerOptions { }
internal sealed class EventConsumerOptions : ConsumerOptions { }

