﻿using Coelsa.Artifact.Kafka.Support.Settings;
using System.Text.RegularExpressions;

namespace Coelsa.Artifact.Kafka.Support;

public static partial class KafkaTools
{
    internal static (QueueOptions, QueueProducerOptions) AddProducerQueueSettings(IServiceCollection services, IConfiguration configuration) => AddSettings<QueueOptions, QueueProducerOptions>(services, configuration, "QueuesOptions", "QueuesProducer");

    internal static (QueueOptions, QueueConsumerOptions) AddConsumerQueueSettings(IServiceCollection services, IConfiguration configuration) => AddSettings<QueueOptions, QueueConsumerOptions>(services, configuration, "QueuesOptions", "QueuesConsumer");

    internal static (EventOptions, EventProducerOptions) AddProducerEventSettings(IServiceCollection services, IConfiguration configuration) => AddSettings<EventOptions, EventProducerOptions>(services, configuration, "EventsOptions", "EventsProducer");

    internal static (EventOptions, EventConsumerOptions) AddConsumerEventSettings(IServiceCollection services, IConfiguration configuration) => AddSettings<EventOptions, EventConsumerOptions>(services, configuration, "EventsOptions", "EventsConsumer");

    private static (E, P) AddSettings<E, P>(IServiceCollection services, IConfiguration configuration, string optionBase, string sectionBase) where E : class, new() where P : class
    {
        IConfigurationSection options = configuration.GetSection($"kafkaOptions:{optionBase}");

        IConfigurationSection section = configuration.GetSection($"kafkaOptions:{sectionBase}");

        services.Configure<E>(options);

        services.Configure<P>(section);

        E config = options.Get<E>() ?? throw new ArgumentException($"No se encuentran los parametros de configuracion, verifique que está la seccion '{nameof(E)}'");

        P response = section.Get<P>() ?? throw new ArgumentException($"No se encuentran los parametros de configuracion, verifique que está la seccion '{nameof(P)}'");

        return (config, response);
    }


    internal static OutboxOptions AddOutboxSettings(IServiceCollection services, IConfiguration configuration)
    {
        IConfigurationSection sectionConfig = configuration.GetSection(nameof(OutboxOptions));

        services.Configure<OutboxOptions>(sectionConfig);

        OutboxOptions options = sectionConfig.Get<OutboxOptions>() ?? throw new ArgumentException($"No se encuentran los parametros de configuracion, verifique que está la seccion '{nameof(OutboxOptions)}'");

        options.SqlServer.Polling.Validate();

        SanitizeAndQuoteSqlIdentifier(options.SqlServer.Initials, nameof(options.SqlServer.Initials), 8);

        return options;
    }

    /// <summary>
    /// Sanitiza y escapa un identificador SQL usando corchetes para prevenir inyección SQL.
    /// </summary>
    /// <param name="identifier">El identificador a sanitizar</param>
    /// <param name="parameterName">Nombre del parámetro para mensajes de error</param>
    private static void SanitizeAndQuoteSqlIdentifier(string identifier, string parameterName, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(identifier))
            throw new ArgumentException($"{parameterName} cannot be null or empty.", parameterName);

        // Validar formato: solo letras y guión bajo
        // Debe comenzar con letra o guión bajo
        if (!SqlSanitize().IsMatch(identifier))
            throw new ArgumentException($"{parameterName} '{identifier}' contains invalid characters. Only letters, numbers, and underscores are allowed, and it must start with a letter or underscore.", parameterName);

        // Validar longitud máxima 
        if (identifier.Length > maxLength)
            throw new ArgumentException($"{parameterName} '{identifier}' exceeds maximum length of {maxLength} characters.", parameterName);

        // Validar contra palabras reservadas de SQL Server
        ValidateNotReservedWord(identifier, parameterName);
    }

    /// <summary>
    /// Valida que el identificador no sea una palabra reservada de SQL Server.
    /// </summary>
    private static void ValidateNotReservedWord(string identifier, string parameterName)
    {
        // Lista de palabras reservadas críticas de SQL Server
        HashSet<string> reservedWords = new(StringComparer.OrdinalIgnoreCase)
        {
            "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
            "EXEC", "EXECUTE", "DECLARE", "SET", "BEGIN", "END", "TRANSACTION",
            "COMMIT", "ROLLBACK", "TRUNCATE", "GRANT", "REVOKE", "DENY",
            "BACKUP", "RESTORE", "SHUTDOWN", "KILL", "TABLE", "DATABASE",
            "SCHEMA", "INDEX", "VIEW", "PROCEDURE", "FUNCTION", "TRIGGER",
            "USER", "LOGIN", "ROLE", "PARTITION", "CONSTRAINT"
        };

        if (reservedWords.Contains(identifier))
            throw new ArgumentException($"{parameterName} '{identifier}' is a SQL Server reserved word and cannot be used.", parameterName);
    }

    [GeneratedRegex(@"^[a-zA-Z_][a-zA-Z_]*$")]
    private static partial Regex SqlSanitize();
}
