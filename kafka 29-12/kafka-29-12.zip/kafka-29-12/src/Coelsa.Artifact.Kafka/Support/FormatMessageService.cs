﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Coelsa.Artifact.Kafka.Support;

internal class FormatMessageService : IFormatMessageService
{
    private static readonly JsonSerializerOptions jsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,

        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,

        WriteIndented = false,

        PropertyNameCaseInsensitive = true,

        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
    };

    public string JsonSerialize<T>(T obj) where T : class
    {
        ArgumentNullException.ThrowIfNull(obj);

        try
        {
            return JsonSerializer.Serialize(obj, jsonOptions);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to serialize object of type '{typeof(T).Name}': {ex.Message}", ex);
        }
    }

    public T? JsonDeserialize<T>(string message) where T : class
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(message);

        try
        {
            return JsonSerializer.Deserialize<T>(message, jsonOptions);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to Deserialize object of type '{typeof(T).Name}': {ex.Message}", ex);
        }
    }
}
