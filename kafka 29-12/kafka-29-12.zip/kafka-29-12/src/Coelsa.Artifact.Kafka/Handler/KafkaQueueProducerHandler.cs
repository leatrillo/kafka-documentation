﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Coelsa.Artifact.Kafka.Handler;

internal class KafkaQueueProducerHandler : IKafkaQueueProducer
{
    private readonly IProducer<string, string> queueProducer;
    private readonly IMessageBuilderService messageBuilder;
    private readonly ILogger<KafkaQueueProducerHandler> logger;

    public KafkaQueueProducerHandler(
        IServiceProvider serviceProvider,
        IMessageBuilderService messageBuilder,
        ILogger<KafkaQueueProducerHandler> logger,
        IOptions<QueueProducerOptions> options)
    {
        this.queueProducer = serviceProvider.GetRequiredKeyedService<IProducer<string, string>>(ProducerType.queue_producer.ToString());

        this.messageBuilder = messageBuilder;

        this.logger = logger;

        if (options.Value.EnableTransaction)
            InitTransactions();
    }

    public void AbortTransaction()
    {
        queueProducer.AbortTransaction();
    }

    public void BeginTransaction()
    {
        queueProducer.BeginTransaction();
    }

    public void CommitTransaction()
    {
        queueProducer.CommitTransaction();
    }

    public void InitTransactions(TimeSpan? timeout = null)
    {
        queueProducer.InitTransactions(timeout ?? TimeSpan.FromSeconds(30));
    }

    public async Task<PersistenceStatus> PublishAsync<T>(string topic, CoelsaMessage<T> message, CancellationToken cancellationToken = default) where T : class
    {
        try
        {
            Message<string, string> kafkaMessage = messageBuilder.BuildMessage(message);

            DeliveryResult<string, string> response = await queueProducer.ProduceAsync(topic, kafkaMessage, cancellationToken);

            return response.Status;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Failed to publish message to topic {Topic}", topic);

            return PersistenceStatus.NotPersisted;
        }
    }
}
