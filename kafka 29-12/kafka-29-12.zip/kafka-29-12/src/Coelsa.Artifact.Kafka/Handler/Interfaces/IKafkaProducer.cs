﻿using Coelsa.Artifact.Kafka.Model;

namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IKafkaProducer
{
    Task<PersistenceStatus> PublishAsync<T>(string topic, CoelsaMessage<T> message, CancellationToken cancellationToken = default) where T : class;
    void InitTransactions(TimeSpan? timeout = null);
    void BeginTransaction();
    void CommitTransaction();
    void AbortTransaction();
}
