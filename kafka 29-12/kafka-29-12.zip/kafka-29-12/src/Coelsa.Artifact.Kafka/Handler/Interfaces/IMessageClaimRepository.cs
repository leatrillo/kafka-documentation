﻿using Coelsa.Artifact.Kafka.Model.SqlServer;

namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IMessageClaimRepository
{
    /// <summary>
    /// Reclama un lote de mensajes pendientes para que esta instancia los procese.
    /// Esta operación debe ser rápida (~10ms) y realizarse bajo DistributedLock.
    /// </summary>
    /// <param name="batchSize">Cantidad máxima de mensajes a reclamar</param>
    /// <param name="cancellationToken">Token de cancelación</param>
    /// <returns>Cantidad de mensajes reclamados exitosamente</returns>
    Task<int> ClaimMessagesAsync(int batchSize, CancellationToken cancellationToken = default);

    /// <summary>
    /// Obtiene todos los mensajes actualmente reclamados por esta instancia que necesitan ser procesados.
    /// Esta operación puede hacerse sin DistributedLock ya que los mensajes ya están asignados.
    /// </summary>
    /// <param name="cancellationToken">Token de cancelación</param>
    /// <returns>Mensajes asignados a esta instancia</returns>
    Task<IEnumerable<OutboxMessages>> GetClaimedMessagesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Libera un mensaje procesado exitosamente de la propiedad de esta instancia.
    /// </summary>
    /// <param name="messageId">ID del mensaje a liberar</param>
    /// <param name="cancellationToken">Token de cancelación</param>
    Task ReleaseProcessedMessageAsync(string messageId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Marca un mensaje reclamado como fallido con información de reintento.
    /// </summary>
    /// <param name="messageId">ID del mensaje a marcar como fallido</param>
    /// <param name="error">Mensaje de error</param>
    /// <param name="nextRetryAt">Fecha/hora para el próximo reintento</param>
    /// <param name="cancellationToken">Token de cancelación</param>
    Task FailClaimedMessageAsync(string messageId, string error, DateTime nextRetryAt, CancellationToken cancellationToken = default);

    /// <summary>
    /// Reclama mensajes huérfanos que fueron reclamados por instancias caídas.
    /// Debe llamarse periódicamente para recuperar mensajes tras fallos de instancia.
    /// </summary>
    /// <param name="orphanageTimeout">Tiempo desde que ClaimedAt debe tener para considerarse huérfano</param>
    /// <param name="cancellationToken">Token de cancelación</param>
    /// <returns>Cantidad de mensajes huérfanos reclamados</returns>
    Task<int> ReclaimOrphanedMessagesAsync(TimeSpan orphanageTimeout, CancellationToken cancellationToken = default);

    /// <summary>
    /// Elimina de forma asincrónica todos los mensajes procesados ​​que se completaron antes de la fecha y hora especificadas.
    /// </summary>
    /// <param name="olderThan">Fecha y hora límite. Los mensajes procesados ​​antes de este valor se eliminarán.</param>
    /// <param name="cancellationToken">Un token de cancelación que se puede utilizar para cancelar la operación de eliminación.</param>
    /// <returns>El resultado de la tarea contiene el número de mensajes eliminados.</returns>
    Task<int> DeleteProcessedMessagesAsync(DateTime olderThan, CancellationToken cancellationToken = default);
}
