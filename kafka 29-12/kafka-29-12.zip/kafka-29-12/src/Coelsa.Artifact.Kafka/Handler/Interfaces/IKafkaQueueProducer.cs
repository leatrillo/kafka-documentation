﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IKafkaQueueProducer : IKafkaProducer { }
