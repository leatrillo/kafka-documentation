﻿using Coelsa.Artifact.Kafka.Model;

namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IMessageBuilderService
{
    Message<string, string> BuildMessage<T>(CoelsaMessage<T> message) where T : class;
}
