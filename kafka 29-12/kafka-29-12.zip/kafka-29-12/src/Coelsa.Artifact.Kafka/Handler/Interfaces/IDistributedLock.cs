﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

internal interface IDistributedLock
{
    /// <summary>
    /// Intenta adquirir un bloqueo con la clave especificada.
    /// </summary>
    /// <param name="key">Clave única para el bloqueo.</param>
    /// <param name="expiration">Tiempo de expiración del bloqueo.</param>
    /// <param name="cancellationToken">Token de cancelación.</param>
    /// <returns>True si se adquirió el bloqueo, false en caso contrario.</returns>
    Task<bool> TryAcquireAsync(string key, TimeSpan expiration, CancellationToken cancellationToken = default);

    /// <summary>
    /// Libera el bloqueo con la clave especificada.
    /// </summary>
    /// <param name="key">Clave única del bloqueo a liberar.</param>
    /// <param name="cancellationToken">Token de cancelación.</param>
    /// <returns>Tarea que representa la operación asíncrona.</returns>
    Task ReleaseAsync(string key, CancellationToken cancellationToken = default);

    ///// <summary>
    ///// Renueva el tiempo de expiración de un bloqueo existente.
    ///// </summary>
    ///// <param name="key">Clave única para el bloqueo.</param>
    ///// <param name="expiration">Nuevo tiempo de expiración.</param>
    ///// <param name="cancellationToken">Token de cancelación.</param>
    ///// <returns>True si el bloqueo fue renovado, false si no existe o expiró.</returns>
    //Task<bool> RenewAsync(string key, TimeSpan expiration, CancellationToken cancellationToken = default);

    ///// <summary>
    ///// Verifica si un bloqueo existe y sigue siendo válido.
    ///// </summary>
    ///// <param name="key">Clave única para el bloqueo.</param>
    ///// <param name="cancellationToken">Token de cancelación.</param>
    ///// <returns>True si el bloqueo existe y es válido, false en caso contrario.</returns>
    //Task<bool> IsLockedAsync(string key, CancellationToken cancellationToken = default);

    ///// <summary>
    ///// Ejecuta una acción mientras se mantiene un bloqueo distribuido.
    ///// </summary>
    ///// <param name="key">Clave única para el bloqueo.</param>
    ///// <param name="expiration">Tiempo de expiración del bloqueo.</param>
    ///// <param name="action">Acción a ejecutar mientras se mantiene el bloqueo.</param>
    ///// <param name="cancellationToken">Token de cancelación.</param>
    ///// <returns>True si se adquirió el bloqueo y se ejecutó la acción, false en caso contrario.</returns>
    //Task<bool> ExecuteWithLockAsync(string key, TimeSpan expiration, Func<CancellationToken, Task> action, CancellationToken cancellationToken = default);

    ///// <summary>
    ///// Ejecuta una función mientras se mantiene un bloqueo distribuido y retorna el resultado.
    ///// </summary>
    ///// <typeparam name="T">Tipo de retorno de la función.</typeparam>
    ///// <param name="key">Clave única para el bloqueo.</param>
    ///// <param name="expiration">Tiempo de expiración del bloqueo.</param>
    ///// <param name="func">Función a ejecutar mientras se mantiene el bloqueo.</param>
    ///// <param name="cancellationToken">Token de cancelación.</param>
    ///// <returns>Una tupla indicando si se adquirió el bloqueo y el resultado de la función.</returns>
    //Task<(bool lockAcquired, T? result)> ExecuteWithLockAsync<T>(string key, TimeSpan expiration, Func<CancellationToken, Task<T>> func, CancellationToken cancellationToken = default);
}
