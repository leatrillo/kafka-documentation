﻿namespace Coelsa.Artifact.Kafka.Handler.Interfaces;

public interface IFormatMessageService
{
    string JsonSerialize<T>(T obj) where T : class;
    T? JsonDeserialize<T>(string message) where T : class;
}
