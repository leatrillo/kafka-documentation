﻿using Coelsa.Artifact.Kafka.Handler;
using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Model.Enum;
using Coelsa.Artifact.Kafka.Support;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System.Reflection;

namespace Coelsa.Artifact.Kafka;

public static class KafkaConsumerExtensions
{
    public static IServiceCollection AddCoelsaConsumerKafkaQueue(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        (QueueOptions config, QueueConsumerOptions queueOptions) = KafkaTools.AddConsumerQueueSettings(services, configuration);

        return AddCoelsaConsumer(services, configuration, environment, config, queueOptions, ConsumerType.queue_consumer);
    }

    public static IServiceCollection AddCoelsaConsumerKafkaEvent(this IServiceCollection services, IConfiguration configuration, string environment)
    {
        (EventOptions config, EventConsumerOptions eventOptions) = KafkaTools.AddConsumerEventSettings(services, configuration);

        return AddCoelsaConsumer(services, configuration, environment, config, eventOptions, ConsumerType.event_consumer);
    }

    internal static IServiceCollection AddCoelsaConsumer(this IServiceCollection services, IConfiguration configuration, string environment, OptionsBase config, ConsumerOptions options, ConsumerType type)
    {
        string? assemblyName = Assembly.GetEntryAssembly()?.GetName().Name;

        string hostname = Environment.MachineName;

        ArgumentNullException.ThrowIfNull(assemblyName);

        ArgumentNullException.ThrowIfNull(environment);

        string groupId = string.IsNullOrWhiteSpace(options.GroupId) ? assemblyName : options.GroupId;

        string consumerType = "queue-consumer";

        if (type == ConsumerType.event_consumer)
            consumerType = "event-consumer";

        string clientId = $"{assemblyName.ToLower()}.{consumerType}.{environment}.{hostname}";

        ConsumerConfig consumerConfig = new()
        {
            BootstrapServers = configuration[config.BootstrapServers],
            ClientId = clientId.ToLower(),
            GroupId = groupId,
            AutoOffsetReset = options.AutoOffsetReset,
            EnableAutoCommit = options.EnableAutoCommit,
            SessionTimeoutMs = (int)options.SessionTimeout.TotalMilliseconds,
            HeartbeatIntervalMs = (int)options.HeartbeatInterval.TotalMilliseconds,
            MaxPollIntervalMs = (int)options.ConsumeTimeout.TotalMilliseconds,
            FetchMinBytes = options.FetchMinBytes,
            EnablePartitionEof = options.EnablePartitionEof,
            SecurityProtocol = SecurityProtocol.SaslSsl,
            SaslMechanism = SaslMechanism.Plain,
            SaslUsername = configuration[config.Security.Username],
            SaslPassword = configuration[config.Security.Password],
            EnableSslCertificateVerification = false,
            IsolationLevel = IsolationLevel.ReadCommitted
        };

        services.AddKeyedSingleton(type.ToString(), (sp, key) => new ConsumerBuilder<string, string>(consumerConfig).Build()
        );

        services.TryAddSingleton<ICoelsaKafkaConsumer, KafkaConsumerHandler>();

        services.TryAddSingleton<IFormatMessageService, FormatMessageService>();

        return services;
    }
}
