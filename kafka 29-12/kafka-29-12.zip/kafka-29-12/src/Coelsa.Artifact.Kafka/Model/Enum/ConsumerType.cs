﻿namespace Coelsa.Artifact.Kafka.Model.Enum;
public enum ConsumerType
{
    queue_consumer,
    event_consumer
}
