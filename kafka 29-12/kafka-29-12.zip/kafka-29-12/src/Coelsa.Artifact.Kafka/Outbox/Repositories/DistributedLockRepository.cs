﻿using Coelsa.Artifact.Kafka.Handler.Interfaces;
using Coelsa.Artifact.Kafka.Outbox.Services;
using Coelsa.Artifact.Kafka.Support.Settings;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Data;

namespace Coelsa.Artifact.Kafka.Outbox.Repositories;

internal class DistributedLockRepository(IOptions<OutboxOptions> options, DbSession session, ILogger<DistributedLockRepository> logger) : IDistributedLock
{
    private readonly SqlServerOptions sqlOptions = options.Value.SqlServer;

    private readonly string instanceId = $"{Environment.MachineName}_{Environment.ProcessId}_{Guid.NewGuid():N}";

    public async Task<bool> TryAcquireAsync(string key, TimeSpan expiration, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(key);

        if (expiration <= TimeSpan.Zero)
            throw new ArgumentException("Expiration must be greater than zero.", nameof(expiration));

        const string sql = @"
            BEGIN TRY
                -- Clean up expired locks first
                DELETE FROM [{0}_DISTRIBUTED_LOCKS] WHERE [DLCK_EXPIRES_AT] < GETUTCDATE();

                -- Try to acquire the lock
                INSERT INTO {0}_DISTRIBUTED_LOCKS ([DLCK_KEY], [DLCK_OWNER], [DLCK_EXPIRES_AT])
                VALUES (@Key, @Owner, @ExpiresAt);

                SELECT 1 AS Success;
            END TRY
            BEGIN CATCH
                -- Lock already exists or other error
                SELECT 0 AS Success;
            END CATCH";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        try
        {
            using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);

            using SqlCommand command = new(formattedSql, connection)
            {
                CommandTimeout = sqlOptions.CommandTimeoutSeconds
            };

            command.Parameters.Add("@Key", SqlDbType.NVarChar, 256).Value = key;

            command.Parameters.Add("@Owner", SqlDbType.NVarChar, 256).Value = instanceId;

            command.Parameters.Add("@ExpiresAt", SqlDbType.DateTime2).Value = DateTime.UtcNow.Add(expiration);

            object result = await command.ExecuteScalarAsync(cancellationToken);

            bool success = Convert.ToBoolean(result);

            return success;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error trying to acquire distributed lock '{Key}'", key);

            return false;
        }
    }

    public async Task ReleaseAsync(string key, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(key);

        const string sql = @"
            DELETE FROM [{0}_DISTRIBUTED_LOCKS]
            WHERE [DLCK_KEY] = @Key AND [DLCK_OWNER] = @Owner";

        string formattedSql = string.Format(sql, sqlOptions.Initials);

        using SqlConnection connection = await session.CreateConnectionAsync(cancellationToken);
        using SqlCommand command = new(formattedSql, connection)
        {
            CommandTimeout = sqlOptions.CommandTimeoutSeconds
        };

        command.Parameters.Add("@Key", SqlDbType.NVarChar, 256).Value = key;

        command.Parameters.Add("@Owner", SqlDbType.NVarChar, 256).Value = instanceId;

        await command.ExecuteNonQueryAsync(cancellationToken);
    }


}
