﻿namespace Coelsa.Artifact.Kafka.Outbox.BackgroundServices.Interfaces;

internal interface IOutboxProcessorService
{
    Task<int> ClaimMessagesPhaseAsync(CancellationToken cancellationToken);
    Task CleanupOrphanedMessagesAsync(CancellationToken cancellationToken);
    Task ProcessClaimedMessagesPhaseAsync(CancellationToken cancellationToken);
    Task<int> DeleteProcessedMessagesAsync(DateTime olderThan, CancellationToken cancellationToken = default);
}
