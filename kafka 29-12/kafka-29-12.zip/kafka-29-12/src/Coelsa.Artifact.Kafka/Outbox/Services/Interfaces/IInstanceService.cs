﻿namespace Coelsa.Artifact.Kafka.Outbox.Services.Interfaces;

internal interface IInstanceService
{
    Guid GetInstanceId();
}
